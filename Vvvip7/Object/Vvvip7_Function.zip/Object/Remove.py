# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:11 2020
# Timestamp In Code: 2020-06-25 21:39:46

final_list = []
for num in duplicate:
    if num not in final_list:
        final_list.append(num)
    return final_list