# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:11 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk melihat detail akun\n - dengan cara login akun via no telp ')
print('____________________________________________________________')
nomor = input('masukkan nomor telepon : ')
password = input('masukkan password : ')
headers = {'User-Agent': 'Mozilla/5.0'}
response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
print(response.json())