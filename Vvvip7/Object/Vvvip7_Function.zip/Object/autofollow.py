# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:12 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk menambahkan fan akun tertentu \n - dengan cara masukkan id akun yang mau di tambahin fan \n - kemudian bot akan follow akun tersebut \n - total fan sejumlah dengan jumlah banyaknya bot')
print(' ')
print('____________________________________________________________')
cid = input('masukkan id user :@')
headers4 = {'User-Agent': 'Mozilla/5.0'}
response4 = requests.get(('https://id-api.spooncast.net/search/user/?keyword=' + cid + ''), headers=headers4)
print(response4.json())
idd = response4.json()['results'][0]['id']
nicknamed = response4.json()['results'][0]['nickname']
print(idd)
print('bot otw fans akun ' + nicknamed)
i = 0
for toket in token:
    try:
        if i % 30 == 0:
            time.sleep(5)
            print('loading')
            ucounter += 1
        headers = {'User-Agent':'' + ualist[ucounter] + '', 
         'Authorization':'Token ' + toket}
        response = requests.post(('https://id-api.spooncast.net/users/' + str(idd) + '/follow/'), headers=headers, timeout=2)
        i += 1
        print(i)
        if status:
            print('berhasil')
        print('end')
    except:
        print('err')

# global ucounter ## Warning: Unused global