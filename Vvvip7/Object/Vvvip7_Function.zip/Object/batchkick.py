# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:13 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print('---HARUS LOGIN AKUN MJ/DJ---')
print(' - digunakan untuk kick banyak akun yang mempunyai nama yang mirip \n - dengan cara masukkan link room \n - kemudian login akun dj / mj \n - kemudian masukkan @id yang ingin dikick')
print(' ')
print('____________________________________________________________')
rscode = 0
txtid = input('masukkan link spoon: ')
while rscode != 1:
    nomor = input('masukkan nomor telepon : ')
    password = input('masukkan password : ')
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
    rscode = response.json()['results'][0]['result_code']
    if rscode != 1:
        print('nomor atau password salah , ulangi lagi')

print('berhasil login')
tokenl = response.json()['results'][0]['token']
print(response.json()['results'][0]['nickname'])
params = {'username': txtid}
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
print('info room')
print('room id: ' + slink)
cid = input('masukkan id user yang mau dikick tanpa @: ')
headers4 = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response4 = requests.get(('https://id-api.spooncast.net/search/user/?keyword=' + cid + ''), headers=headers4)
print('debug1')
nexts = response4.json()['next']
print('debug2')
idd2 = []
for i in range(0, len(response4.json()['results'])):
    idd2.append(str(response4.json()['results'][int(i)]['id']))

while nexts != '':
    print('==========================')
    response6 = requests.get(nexts, headers=headers4)
    link1 = response6.json()['next']
    print(link1)
    nexts = link1
    for i in range(0, len(response6.json()['results'])):
        idd2.append(str(response6.json()['results'][int(i)]['id']))

headersz = {'User-Agent':'Mozilla/5.0', 
 'Authorization':'Token ' + tokenl}
print('debug3')
print(idd2)
il = 0
for idkickers in idd2:
    try:
        print('debug4')
        response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/block/'), headers=headersz, json={'block_user_id': idkickers}, params={'cv': 'heimdallr'})
        print(idd2[int(il)] + ' berhasil dikick')
        print(il)
        il += 1
    except:
        print('error')