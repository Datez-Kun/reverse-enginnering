# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:29 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk memblock dari bot \n - dengan cara masukkan @id yang ingin diblock')
print(' ')
print('____________________________________________________________')
cid = input('masukkan id user :@')
headers4 = {'User-Agent': 'Mozilla/5.0'}
response4 = requests.get(('https://id-api.spooncast.net/search/user/?keyword=' + cid + ''), headers=headers4)
idd = response4.json()['results'][0]['id']
slink = idd
print(idd)
proxy_host = '138.68.24.145'
proxy_port = '8080'
proxy_auth = ':'
proxies = {'https':'https://{}@{}:{}/'.format(proxy_auth, proxy_host, proxy_port), 
 'http':'http://{}@{}:{}/'.format(proxy_auth, proxy_host, proxy_port)}
il = 0
for tokenl in token:
    try:
        headersz = {'User-Agent':'' + ualist[ucounter] + '', 
         'Authorization':'Token ' + tokenl}
        response = requests.post(('https://id-api.spooncast.net/users/' + str(slink) + '/block/'), headers=headersz, timeout=2)
        print(il)
        print(response.json())
        il += 1
        if il == 50:
            ucounter += 1
    except:
        ucounter += 1
        print('error')

# global ucounter ## Warning: Unused global