# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:31 2020
# Timestamp In Code: 2020-06-25 21:39:46

params = {'cv': 'heimdallr2'}
try:
    headersz = {'User-Agent':'' + ualist[ucounter] + '',  'Authorization':'Token ' + token[z]}
    response = requests.post(('https://id-api.spooncast.net/lives/' + str(idroomreport) + '/like/'), headers=headersz, params=params, timeout=2)
    print(z)
    z += 1
    if z != 500 and saklarbom == True:
        threading.Timer(0.01, bomnem).start()
        if z % 50 == 0:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"bomlike bot ' + namareport + ' ke ' + str(z) + ' berhasil "}')
    else:
        if saklarbom == True:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses selesai  .  muehehehe "}')
        else:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses bomlike di hentikan boss "}')
        z = 0
except:
    print('err')

# global z ## Warning: Unused global