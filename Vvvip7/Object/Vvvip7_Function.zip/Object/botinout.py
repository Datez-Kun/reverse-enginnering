# Filename : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 23:13:01 2020
# Timestamp In Code : 2020-07-16 04:45:22
# Deleting Exception Match In File botinout.pyc

signa()
print('[ INFO ]')
print(' - digunakan untuk memasukkan bot dan taplop \n - dengan cara masukkan link room \n - waktu delay \n - jumlah bot \n - BOT MASUK KELIHATAN \n - BOT TAPLOP KELIHATAN \n - bot langsung keluar setelah taplop')
print(' ')
print('____________________________________________________________')
print('contoh link spoon : https://u8kv3.app.goo.gl/W26u3')
txtid = input('masukkan link spoon: ')
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
joinmode = ''
waktu = input('masukkan waktu: ')
jumlahbot = 50
jumlah = input('Masukkan jumlah taplop (maksimal sejumlah total bot) : ')
a = int(jumlah)
if a > 0:
    jumlahbot = jumlah
i = 1
for toket in token:
    if i == a + 1:
        ws = create_connection(('wss://id-heimdallr.spooncast.net/' + slink), timeout=2)
        pesan = '{"live_id":' + slink + ',"token":"' + toket + '","event":"live_' + joinmode + 'join","appversion":"4.3.18","useragent":"Android"}'
        ws.send(pesan)
        result = ws.recv()
        ws.send(pesan)
        results = json.loads(result)
        islike = False
        time.sleep(int(waktu))
        params = {'cv': 'heimdallr'}
        headers = {'User-Agent':'' + ualist[ucounter] + '',  'Authorization':'Token ' + toket}
        if islike == False:
            response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/like/'), params=params, headers=headers)
            print('bot ke ' + str(i) + ' berhasil')
            i += 1
            response7 = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/' + 'leave' + '/'), params=params, headers=headers)
            if i == 50:
                ucounter += 1
        else:
            print('skip , udah taplop')
        ws.close()
        print('end')
