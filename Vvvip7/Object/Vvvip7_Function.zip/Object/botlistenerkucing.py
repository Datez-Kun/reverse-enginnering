# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:36 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk memasukkan bot dan taplop \n - dengan cara masukkan link room \n - waktu delay \n - jumlah bot \n - BOT MASUK TIDAK KELIHATAN \n - BOT TAPLOP KELIHATAN \n - bot stay di room')
print(' ')
print('____________________________________________________________')
print('contoh link spoon : https://u8kv3.app.goo.gl/W26u3')
txtid = input('masukkan link spoon: ')
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
joinmode = ''
waktu = input('masukkan waktu: ')
jumlahbot = 50
jumlah = input('Masukkan jumlah taplop (maksimal sesuai jumlah bot) : ')
a = int(jumlah)
if a > 0:
    jumlahbot = jumlah
params = {'cv': 'heimdallr2'}
random.shuffle(token)
i = 1
for toket in token:
    try:
        if i % 50 == 0:
            print('istirahat 5 detik')
            time.sleep(5)
            ucounter += 1
        else:
            if i == a + 1:
                break
            time.sleep(int(waktu))
            headers = {'User-Agent':'' + ualist[ucounter] + '', 
             'Authorization':'Token ' + toket}
            response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/join/'), params=params, headers=headers)
            islike = response.json()['results'][0]['live']['is_like']
            if islike == False:
                response2 = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/like/'), params=params, headers=headers)
                i += 1
                print(i)
            else:
                print('skip karena sudah taplop')
    except:
        print('err')

# global ucounter ## Warning: Unused global