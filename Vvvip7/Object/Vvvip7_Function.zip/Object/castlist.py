# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:38 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk menambahkan jumlah listener cast target \n - dengan cara masukkan link cast \n - kemudian otomatis akan menambahkan 100++ listener cast target')
print(' ')
print('____________________________________________________________')
txtid = input('masukkan link spoon: ')
params = {'username': txtid}
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
print(url)
slink = url[34:-58]
print(slink)
iii = 1
for z in range(0, random.randint(30, 50)):
    try:
        resp = requests.post(('https://id-api.spooncast.net/casts/' + slink + '/play/'), headers=headers, timeout=2)
        print(iii)
        iii += 1
    except:
        print('ERR')

print("listener cast sudah bertambah :')")