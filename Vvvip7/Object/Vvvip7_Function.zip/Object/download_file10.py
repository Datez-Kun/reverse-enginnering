# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:42 2020
# Timestamp In Code: 2020-06-25 21:39:46

try:
    ws = create_connection(('wss://id-heimdallr.spooncast.net/' + slink), timeout=2)
    pesan = '{"live_id":' + slink[:-1] + ',"token":"' + toket + '","event":"live_join","appversion":"4.3.18","useragent":"Android"}'
    ws.send(pesan)
except:
    print('error')