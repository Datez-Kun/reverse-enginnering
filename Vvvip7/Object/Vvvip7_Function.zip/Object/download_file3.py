# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:43 2020
# Timestamp In Code: 2020-06-25 21:39:46

headers = {'user-agent':'' + ualist[ucounter] + '', 
 'Authorization':'Token ' + toket}
params = {'cv': 'heimdallr'}
html = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/like/'), headers=headers, params=params)
if html:
    print('berhasil')
else:
    ucounter += 1
    print('gagal')
