# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:45 2020
# Timestamp In Code: 2020-06-25 21:39:46

try:
    headers = {'User-Agent':'' + ualist[ucounter] + '', 
     'Authorization':'Token ' + toket}
    response = requests.post(('https://id-api.spooncast.net/casts/' + slink + '/like/'), headers=headers, timeout=2)
    if response:
        print('berhasil')
    else:
        ucounter += 1
        print('gagal')
except:
    print('error')

# global ucounter ## Warning: Unused global