# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:47 2020
# Timestamp In Code: 2020-06-25 21:39:46

try:
    headers = {'User-Agent':'' + ualist[ucounter] + '', 
     'Authorization':'Token ' + tokennya}
    response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/block/'), headers=headers, json={'block_user_id': toket}, params={'cv': 'heimdallr'})
    print(response.json())
    if response:
        print('berhasil')
    else:
        ucounter += 1
        print('gagal')
except:
    print('error')

# global ucounter ## Warning: Unused global