# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:49 2020
# Timestamp In Code: 2020-06-25 21:39:46

params = {'cv': 'heimdallr2'}
try:
    headersz = {'User-Agent':'' + ualist[ucounter] + '',  'Authorization':'Token ' + token[y]}
    response = requests.post(('https://id-api.spooncast.net/lives/' + str(idroomreport) + '/leave/'), headers=headersz, params=params, timeout=2)
    print(y)
    y += 1
    if y != 700 and saklardown == True:
        threading.Timer(0.01, downnem).start()
        if y % 50 == 0:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Tarik bot ' + namareport + ' ke ' + str(y) + ' berhasil "}')
    else:
        if saklardown == True:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses selesai  .  muehehehe "}')
        else:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses tarik di hentikan boss "}')
        y = 0
except:
    print('err')

# global y ## Warning: Unused global