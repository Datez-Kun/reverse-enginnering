# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:53 2020
# Timestamp In Code: 2020-06-25 21:39:46

pesan = '{"event":"live_health","type":"live_rpt","live_id":' + slink + ',"user_id":' + userid + ',"useragent":"Android","appversion":"4.3.22"}'
print('ini counrr ' + str(counrr))
if counrr > 0:
    ws.send(pesan)
threading.Timer(25, foo).start()