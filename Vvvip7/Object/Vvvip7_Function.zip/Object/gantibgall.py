# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:32:54 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk mengganti background dengan pp random \n - dengan cara login via notelepon dan password akun DJ \n - kemudian masukkan sharelink room live \n - kemudian masukkan delay ganti bg dalam detik (misal : 3) - \n - yang berarti bg akan berganti tiap +- 3 detik ')
print(' ')
print('____________________________________________________________')
rscode = 0
while rscode != 1:
    nomor = input('masukkan nomor telepon : ')
    password = input('masukkan password : ')
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
    rscode = response.json()['results'][0]['result_code']
    if rscode != 1:
        print('nomor atau password salah , ulangi lagi')

print('berhasil login')
tokenl = response.json()['results'][0]['token']
print(response.json()['results'][0]['nickname'])
print(response.json()['results'][0]['tag'])
tokenkucing = tokenl
txtid = input('masukkan link spoon: ')
headers = {'User-Agent':'Mozilla/5.0', 
 'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
delayganti = int(input('Masukkan delay : '))
rangeawal = random.randint(211100000, 211888888)
a = list(range(rangeawal, rangeawal + 5000))
pplist = []
i = 0
ind = 0
for tokens in a:
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(('https://id-api.spooncast.net/users/' + str(tokens) + '/'), headers=headers)
        kambeng = response.json()['results'][0]['profile_url']
        if kambeng[:28] == 'http://id-cdn.spooncast.net/':
            toket = '4686c81a92cf1fbed3589f1a7f1d5d45d3bc0dbb'
            toket = tokenkucing
            params = {'cv': 'heimdallr'}
            headers = {'User-Agent':'Mozilla/5.0',  'Authorization':'Token ' + toket}
            jsonbg = {'img_key': '' + kambeng[28:] + ''}
            response = requests.put(('https://id-api.spooncast.net/lives/' + slink + '/'), params=params, headers=headers, json=jsonbg)
            print(response.json())
            time.sleep(delayganti)
            pplist.append(kambeng[28:])
            print(i)
            print('debyg 0')
            print(pplist[ind])
            print('debug1')
            headers2 = {'User-Agent':'Mozilla/5.0',  'Authorization':'Token ' + listtoken[i] + ''}
            print('debug2')
            response2 = requests.put(('https://id-api.spooncast.net/users/' + listid[i] + '/'), headers=headers2, json={'profile_key': pplist[i]})
            print('debug3')
            print(response.json())
            i += 1
            ind += 1
    except:
        print('internet error')