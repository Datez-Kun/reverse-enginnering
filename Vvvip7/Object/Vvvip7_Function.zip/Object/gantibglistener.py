# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:33:02 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk mengganti background dengan pp listener \n - dengan cara login via notelepon dan password akun DJ \n - kemudian masukkan sharelink room live \n - kemudian masukkan delay ganti bg dalam detik (misal : 3) - \n - yang berarti bg akan berganti tiap +- 3 detik ')
print(' ')
print('____________________________________________________________')
rscode = 0
while rscode != 1:
    nomor = input('masukkan nomor telepon : ')
    password = input('masukkan password : ')
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
    rscode = response.json()['results'][0]['result_code']
    if rscode != 1:
        print('nomor atau password salah , ulangi lagi')
    print('berhasil login')
    tokenl = response.json()['results'][0]['token']
    print(response.json()['results'][0]['nickname'])
    tokenkucing = tokenl
    txtid = input('masukkan link spoon: ')
    headers = {'User-Agent':'Mozilla/5.0', 
     'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
    response = requests.get(txtid)
    url = response.url
    slink = url[34:-59]
    response5 = requests.get(('https://id-api.spooncast.net/lives/' + slink + '/members'), headers=headers)
    nexts = response5.json()['next']
    idd2 = []
    profil = []
    for i in range(0, len(response5.json()['results'])):
        idd2.append(str(response5.json()['results'][int(i)]['id']))
        profil.append(response5.json()['results'][int(i)]['profile_url'])
        print(response5.json()['results'][int(i)]['profile_url'])

    if nexts != '':
        print('============================')
        response6 = requests.get(nexts, headers=headers)
        link1 = response6.json()['next']
        nexts = link1
        for i in range(0, len(response6.json()['results'])):
            idd2.append(str(response6.json()['results'][int(i)]['id']))
            if len(str(response6.json()['results'][int(i)]['profile_url'])) == 94:
                profil.append(response6.json()['results'][int(i)]['profile_url'])
                print(response6.json()['results'][int(i)]['profile_url'])

    else:
        print('debug')
        print(len(profil))
        print(profil)
        print('a')
        il = 0
        profil = list(dict.fromkeys(profil))
        print(len(profil))
        for idkickers in profil:
            try:
                if il >= 0:
                    toket = tokenkucing
                    params = {'cv': 'heimdallr'}
                    headers = {'User-Agent':'Mozilla/5.0',  'Authorization':'Token ' + toket}
                    jsonbg = {'img_key': '' + idkickers[28:] + ''}
                    response = requests.put(('https://id-api.spooncast.net/lives/' + slink + '/'), params=params, headers=headers, json=jsonbg)
                    print(response.json())
                    time.sleep(4)
                    il += 1
            except:
                print('error')