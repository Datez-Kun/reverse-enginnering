# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:33:17 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk ganti id \n - tinggal login akun via no telp \n - ganti id baru')
print('____________________________________________________________')
rscode = 0
while rscode != 1:
    nomor = input('masukkan nomor telepon : ')
    password = input('masukkan password : ')
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
    rscode = response.json()['results'][0]['result_code']
    if rscode != 1:
        print('nomor atau password salah , ulangi lagi')

print('berhasil login')
tokenl = response.json()['results'][0]['token']
print(response.json()['results'][0]['nickname'])
txtid = input('masukkan id baru : @')
params = {'username': txtid}
headers = {'User-Agent':'Mozilla/5.0',  'Authorization':'Token ' + tokenl}
data = {'username': txtid}
data_json = json.dumps(data)
payload = {'json_payload', data_json}
response = requests.post('https://id-api.spooncast.net/users/username/', headers=headers, json={'username': txtid})
print(response.json())
if response.json()['status_code'] == 400:
    print('id tersebut telah dipakai orang lain atau dilarang oleh mimin')
else:
    if response.json()['status_code'] == 200:
        print("id telah terganti :') silahkan cek")