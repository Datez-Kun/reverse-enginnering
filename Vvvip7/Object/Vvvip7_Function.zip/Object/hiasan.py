# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:33:24 2020
# Timestamp In Code: 2020-06-25 21:39:46

os.system('clear')
print('hello')
print('\x1b[1;33;42m coba aja')