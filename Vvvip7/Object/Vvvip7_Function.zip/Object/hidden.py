# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:33:24 2020
# Timestamp In Code: 2020-06-25 21:39:46

random.shuffle(token)
signa()
print('[ INFO ]')
print(' - digunakan untuk menghidden room \n - dengan cara bot akan mereport room target \n - fitur ini masih di disable oleh mimin')
print(' - tinggal masukkan link target \n - misal : https://u8kv3.app.goo.gl/MR8BZ')
print('____________________________________________________________')
txtid = input('masukkan link spoon disini: ')
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
i = 0
for toket in token:
    try:
        i += 1
        if i == 10:
            break
        ws = create_connection(('wss://id-heimdallr.spooncast.net/' + slink), timeout=1)
        pesan = '{"live_id":' + slink + ',"token":"' + toket + '","event":"live_join"}'
        ws.send(pesan)
        ws.send(pesan)
        result = ws.recv()
        print(i)
    except:
        print('proses ' + str(i))

z = 1
for toket in token:
    try:
        if z == 10:
            break
        else:
            headers = {'User-Agent':'Mozilla/5.0', 
             'Authorization':'Token ' + toket}
            response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/report/'), headers=headers, json={'report_type': 1})
            if response:
                print('proses...')
            else:
                print('err')
        print(z)
        z += 1
    except:
        print('gagal')

print('SUKSES TERHIDDEN')