# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:33:25 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print('---HARUS LOGIN AKUN MJ/DJ---')
print(' - digunakan untuk kick 1 akun \n - dengan cara masukkan link room \n - kemudian login akun dj / mj \n - kemudian masukkan @id yang ingin dikick \n - kalau hoki bisa kick dj / mj hehe')
print(' ')
print('____________________________________________________________')
rscode = 0
txtid = input('masukkan link spoon: ')
while rscode != 1:
    nomor = input('masukkan nomor telepon : ')
    password = input('masukkan password : ')
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
    rscode = response.json()['results'][0]['result_code']
    if rscode != 1:
        print('nomor atau password salah , ulangi lagi')

print('berhasil login')
tokenl = response.json()['results'][0]['token']
print(response.json()['results'][0]['nickname'])
params = {'username': txtid}
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
print('info room')
print('room id: ' + slink)
response2 = requests.get('https://id-api.spooncast.net/lives/' + slink)
print('room dj: ' + response2.json()['results'][0]['author']['nickname'])
print('judul room: ' + response2.json()['results'][0]['title'])
cid = input('masukkan id user yang mau dikick tanpa @: ')
headers4 = {'User-Agent': 'Mozilla/5.0'}
response4 = requests.get(('https://id-api.spooncast.net/search/user/?keyword=' + cid + ''), headers=headers4)
idd = []
unn = []
print('proses kick ...')
for i in range(0, len(response4.json()['results'])):
    idd.append(int(response4.json()['results'][int(i)]['id']))
    print(i)
    uname = response4.json()['results'][int(i)]['nickname']
    unn.append(str(uname))
    uid = response4.json()['results'][0]['tag']
    print('kick dengan nama ' + response4.json()['results'][int(i)]['nickname'] + ' dengan id @' + response4.json()['results'][int(i)]['tag'] + ' ')
    i += 1

headers = {'User-Agent':'Mozilla/5.0', 
 'Authorization':'Token ' + tokenl}
il = 0
if 1 == 1:
    try:
        if il == 0:
            response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/block/'), headers=headers, json={'block_user_id': idd[0]}, params={'cv': 'heimdallr'})
            print(unn[int(il)] + ' berhasil dikick')
            print(il)
            il += 1
    except:
        print('error')