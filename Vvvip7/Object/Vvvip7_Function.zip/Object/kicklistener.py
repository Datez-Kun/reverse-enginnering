# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Wed Aug 26 23:33:46 2020
# Timestamp In Code: 2020-06-25 21:39:46

rscode = 0
signa()
print('[ INFO ]')
print(' ---HARUS LOGIN AKUN MJ / DJ---')
print(' - digunakan untuk kick semua listener pada room tertentu \n - harus login via no telp akun mj /dj ')
print(' - tinggal masukkan link target \n - misal : https://u8kv3.app.goo.gl/MR8BZ')
print('____________________________________________________________')
txtid = input('masukkan link spoon: ')
while rscode != 1:
    nomor = input('masukkan nomor telepon : ')
    password = input('masukkan password : ')
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
    rscode = response.json()['results'][0]['result_code']
    if rscode != 1:
        print('nomor atau password salah , ulangi lagi')

print('berhasil login')
tokenl = response.json()['results'][0]['token']
print(response.json()['results'][0]['nickname'])
params = {'username': txtid}
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
response5 = requests.get(('https://id-api.spooncast.net/lives/' + slink + '/members'), headers=headers)
nexts = response5.json()['next']
idd2 = []
profil = []
for i in range(0, len(response5.json()['results'])):
    idd2.append(str(response5.json()['results'][int(i)]['id']))
    profil.append(response5.json()['results'][int(i)]['profile_url'][28:])

while nexts != '':
    print('============================')
    response6 = requests.get(nexts, headers=headers)
    link1 = response6.json()['next']
    print(link1)
    nexts = link1
    for i in range(0, len(response6.json()['results'])):
        idd2.append(str(response6.json()['results'][int(i)]['id']))
        profil.append(response5.json()['results'][int(i)]['profile_url'][28:])

print('debug')
print(len(idd2))
print(idd2)
headers = {'User-Agent':'Mozilla/5.0', 
 'Authorization':'Token ' + tokenl}
il = 0
print(len(idd2))
for idkickers in idd2:
    try:
        if il > 3:
            response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/block/'), headers=headers, json={'block_user_id': idkickers}, params={'cv': 'heimdallr'})
            print(idkickers + ' berhasil dikick')
            print(il)
        il += 1
    except:
        print('error')