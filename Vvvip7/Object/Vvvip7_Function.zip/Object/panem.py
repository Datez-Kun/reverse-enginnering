# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:22 2020
# Timestamp In Code: 2020-06-25 21:39:46

params = {'cv': 'heimdallr2'}
try:
    if i % 50 == 0:
        print('istirahat 5 detik')
        ucounter += 1
    elif i != pembatas:
        if saklarpanem == True:
            threading.Timer(1, panem).start()
        else:
            if saklarpanem == True:
                ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses selesai  .  muehehehe "}')
            else:
                ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Siap , proses up room dihentikan "}')
            i = 0
        headers = {'User-Agent':'' + ualist[ucounter] + '', 
         'Authorization':'Token ' + token[i]}
        response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/join/'), params=params, headers=headers)
        islike = response.json()['results'][0]['live']['is_like']
        if islike == False:
            response2 = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/like/'), params=params, headers=headers)
            i += 1
            print(i)
    else:
        print('skip karena sudah taplop')
except:
    print('err')

# global i ## Warning: Unused global
# global ucounter ## Warning: Unused global