# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:26 2020
# Timestamp In Code: 2020-06-25 21:39:46

try:
    headersz = {'User-Agent':'' + ualist[ucounter] + '', 
     'Authorization':'Token ' + token[j]}
    response = requests.post(('https://id-api.spooncast.net/users/' + str(uidreport) + '/report/'), headers=headersz, json={'report_type': 1}, timeout=2)
    print(j)
    j += 1
    if j != 50 and saklarrenem == True:
        threading.Timer(1, renem).start()
        if j % 5 == 0:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Report ' + namareport + ' ke ' + str(j) + ' berhasil "}')
    else:
        if saklarrenem == True:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses selesai  .  muehehehe "}')
        else:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses report di hentikan boss "}')
        j = 0
except:
    print('err')
