# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:29 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk mereport profil akun tertentu \n - dengan cara masukkan @id yang ingin direport')
print(' ')
print('____________________________________________________________')
cid = input('masukkan id user :@')
headers4 = {'User-Agent': 'Mozilla/5.0'}
response4 = requests.get(('https://id-api.spooncast.net/search/user/?keyword=' + cid + ''), headers=headers4)
print(response4.json())
idd = response4.json()['results'][0]['id']
nicknamed = response4.json()['results'][0]['nickname']
slink = idd
print(slink)
print('proses report ' + nicknamed)
il = 0
for tokenl in token:
    try:
        headersz = {'User-Agent':'' + ualist[ucounter] + '', 
         'Authorization':'Token ' + tokenl}
        response = requests.post(('https://id-api.spooncast.net/users/' + str(slink) + '/report/'), headers=headersz, json={'report_type': 1}, timeout=2)
        print(il)
        print(response.json())
        il += 1
        if il == 50:
            ucounter += 1
    except:
        print('error')
