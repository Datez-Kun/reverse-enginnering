# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:31 2020
# Timestamp In Code: 2020-06-25 21:39:46

print('contoh link spoon : https://u8kv3.app.goo.gl/W26u3')
txtid = input('masukkan link spoon: ')
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
params = {'cv': 'heimdallr'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
joinmode = ''
i = 0
for toket in token:
    try:
        headers = {'User-Agent':'Mozilla/5.0', 
         'Authorization':'Token ' + toket}
        response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/join/'), params=params, headers=headers)
        i += 1
        print(i)
        ws = create_connection(('wss://id-heimdallr.spooncast.net/' + slink), timeout=2)
        pesan = '{"live_id":' + slink + ',"token":"' + toket + '","event":"live_like"}'
        ws.send(pesan)
        result = ws.recv()
        ws.close()
        print('end')
    except:
        print('err')