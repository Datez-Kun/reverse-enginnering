# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:33 2020
# Timestamp In Code: 2020-06-25 21:39:46

for c in s + '\n':
    sys.stdout.write(c)
    sys.stdout.flush()
    time.sleep(0.01)