# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:34 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk menambahkan taplop cast \n - dengan cara bot akan taplop cast target')
print(' - tinggal masukkan link target \n - misal : https://u8kv3.app.goo.gl/MR8BZ')
print('____________________________________________________________')
txtid = input('masukkan link spoon: ')
params = {'username': txtid}
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
totsuntik = int(input('mau berapa taplop? : '))
url = response.url
print(url)
slink = url[34:-58]
print(slink)
i = 1
for toket in token:
    try:
        headers = {'User-Agent':'' + ualist[ucounter] + '', 
         'Authorization':'Token ' + toket}
        response = requests.post(('https://id-api.spooncast.net/casts/' + slink + '/like/'), headers=headers, timeout=2)
        if response:
            print('berhasil')
        else:
            print('gagal')
        print(i)
        if i % 50 == 0:
            print('loading.')
            time.sleep(1)
            print('loading..')
            time.sleep(1)
            print('loading...')
            time.sleep(1)
            print('loading....')
            time.sleep(1)
            ucounter += 1
        if i == totsuntik:
            break
        i += 1
    except:
        ucounter += 1
        print(response.json())
        print('err')

# global ucounter ## Warning: Unused global