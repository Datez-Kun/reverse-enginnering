# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:36 2020
# Timestamp In Code: 2020-06-25 21:39:46

print('contoh link spoon : https://u8kv3.app.goo.gl/W26u3')
txtid = input('masukkan link spoon: ')
headers = {'User-Agent':'Mozilla/5.0',  'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'}
response = requests.get(txtid)
url = response.url
slink = url[34:-59]
print(slink)
joinmode = ''
params = {'cv': 'heimdallr2'}
ii = 0
for toket in token:
    try:
        ii += 1
        headers = {'User-Agent':'Mozilla/5.0',  'Authorization':'Token ' + toket}
        response = requests.post(('https://id-api.spooncast.net/lives/' + slink + '/' + 'leave' + '/'), params=params, headers=headers)
        print(ii)
        print('proses')
    except:
        print('error')