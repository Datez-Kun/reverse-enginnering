# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:37 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk menghapus semua list block \n - login akun terlebih dahulu via no telp dan password \n - akan otomatis meng unblock semua dari daftar block')
print('____________________________________________________________')
rscode = 0
while rscode != 1:
    nomor = input('masukkan nomor telepon : ')
    password = input('masukkan password : ')
    headers = {'User-Agent': 'Mozilla/5.0'}
    response = requests.post('https://id-api.spooncast.net/signin/?version=2', headers=headers, json={'sns_type':'phone',  'sns_id':nomor,  'password':password})
    rscode = response.json()['results'][0]['result_code']
    if rscode != 1:
        print('nomor atau password salah , ulangi lagi')

print('berhasil login')
tokenl = response.json()['results'][0]['token']
print(response.json()['results'][0]['nickname'])
headers = {'User-Agent':'Mozilla/5.0', 
 'Authorization':'Token ' + tokenl}
response5 = requests.get('https://id-api.spooncast.net/users/blocked', headers=headers)
nexts = response5.json()['next']
idd2 = []
for i in range(0, len(response5.json()['results'])):
    idd2.append(str(response5.json()['results'][int(i)]['id']))

while nexts != '':
    print('========================')
    response6 = requests.get(nexts, headers=headers)
    link1 = response6.json()['next']
    print(link1)
    nexts = link1
    for i in range(0, len(response6.json()['results'])):
        idd2.append(str(response6.json()['results'][int(i)]['id']))

print('debug')
print(len(idd2))
print(idd2)
il = 0
for idkickers in idd2:
    try:
        response = requests.post(('https://id-api.spooncast.net/users/' + idkickers + '/unblock/'), headers=headers)
        print(idkickers + ' berhasil dibersihkan')
        print(il)
        il += 1
    except:
        print('error')