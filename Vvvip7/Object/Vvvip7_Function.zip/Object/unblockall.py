# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 23:25:30 2020
# Timestamp In Code: 2020-07-16 04:45:22

signa()
print('[ INFO ]')
print(' - digunakan untuk membuka block dari bot \n - dengan cara masukkan @id yang ingin diunblock')
print(' ')
print('____________________________________________________________')
cid = input('masukkan id user :@')
headers4 = {'User-Agent': 'Mozilla/5.0'}
response4 = requests.get(('https://id-api.spooncast.net/search/user/?keyword=' + cid + ''), headers=headers4)
idd = response4.json()['results'][0]['id']
slink = str(idd)
print(slink)
print(type(slink))
uwa = 0
for tokenl in token:
    print(uwa)

try:
    headers = {'User-Agent':'' + ualist[ucounter] + '', 
     'Authorization':'Token ' + tokenl}
    response5 = requests.get('https://id-api.spooncast.net/users/blocked', headers=headers, timeout=2)
    if response5.json()['status_code'] != '200':
        ucounter += 1
    nexts = response5.json()['next']
    idd2 = []
    nn2 = []
except:
    print('err1')
else:
    for i in range(0, len(response5.json()['results'])):
        if str(response5.json()['results'][int(i)]['id']) == slink:
            idd2.append(str(response5.json()['results'][int(i)]['id']))
            nn2.append(str(response5.json()['results'][int(i)]['nickname']))
        if nexts != '':
            try:
                print('========================')
                response6 = requests.get(nexts, headers=headers)
                link1 = response6.json()['next']
                print(link1)
                nexts = link1
            except:
                print('err2')
            else:
                try:
                    for i in range(0, len(response6.json()['results'])):
                        if str(response5.json()['results'][int(i)]['id']) == slink:
                            idd2.append(str(response6.json()['results'][int(i)]['id']))

                except:
                    print('error disini')

        else:
            print('debug')
            print(len(idd2))
            print(idd2)
            il = 0
            for idkickers in idd2:
                try:
                    response = requests.post(('https://id-api.spooncast.net/users/' + idkickers + '/unblock/'), headers=headers)
                    print(idkickers + ' berhasil dibersihkan ' + nn2[il])
                    print(il)
                    il += 1
                except:
                    print('error')

            uwa += 1


