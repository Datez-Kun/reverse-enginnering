# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:49 2020
# Timestamp In Code: 2020-06-25 21:39:46

params = {'cv': 'heimdallr2'}
try:
    headersz = {'User-Agent':'' + ualist[ucounter] + '',  'Authorization':'Token ' + token[x]}
    response = requests.post(('https://id-api.spooncast.net/lives/' + str(idroomreport) + '/join/'), headers=headersz, params=params, timeout=2)
    print(x)
    x += 1
    if x != 500 and saklarup == True:
        threading.Timer(0.01, upnem).start()
        if x % 50 == 0:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Bot masuk room ' + namareport + ' ke ' + str(x) + ' berhasil "}')
    else:
        if saklarup == True:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses selesai  .  muehehehe "}')
        else:
            ws.send('{"appversion":"4.3.22","event":"live_message","token":"29b0534f029ff4614cffbd466a5c1b2327f65f72","useragent":"Android","message":"Proses up di hentikan boss "}')
        x = 0
except:
    print('err')
