# FileName : 
# Python Bytecode : 3.8
# Time Succses Decompiled : Thu Aug 27 22:45:52 2020
# Timestamp In Code: 2020-06-25 21:39:46

signa()
print('[ INFO ]')
print(' - digunakan untuk mengganti voice type / tipe suara \n - dengan cara masukkan @id target \n - masukkan tipe suara yang diinginkan \n - kemudian bot akan otomatis vote suara yang diinginkan')
print(' ')
print('____________________________________________________________')
cid = input('masukkan id user yang mau diganti voice typenya tanpa @: ')
headers4 = {'User-Agent': 'Mozilla/5.0'}
response4 = requests.get(('https://id-api.spooncast.net/search/user/?keyword=' + cid + ''), headers=headers4)
idd = []
unn = []
for i in range(0, len(response4.json()['results'])):
    idd.append(str(response4.json()['results'][int(i)]['id']))
    uname = response4.json()['results'][int(i)]['nickname']
    unn.append(str(uname))
    uid = response4.json()['results'][0]['tag']
    i += 1

print('=====')
print('nickname = ' + unn[0])
type = '0'
print('=====')
print('1. manis')
print('2. imut')
print('3. seksi')
print('4. seram')
print('5. halus')
print('6. hangat')
print('7. ramah')
print('8. keren')
print('9. lucu')
print('10. bersahabat')
print('11. serak')
print('12. kuat')
print('13. keras')
print('14. romantis')
pil = int(input('masukkan nomor pilihan anda: '))
if pil == 1:
    type = '1'
if pil == 2:
    type = '11'
if pil == 3:
    type = '2'
if pil == 4:
    type = '14'
if pil == 5:
    type = '6'
if pil == 6:
    type = '5'
if pil == 7:
    type = '3'
if pil == 8:
    type = '4'
if pil == 9:
    type = '9'
if pil == 10:
    type = '7'
if pil == 11:
    type = '12'
if pil == 12:
    type = '8'
if pil == 13:
    type = '10'
if pil == 14:
    type = '13'
il = 0
for toket in token:
    try:
        headers = {'User-Agent':'' + ualist[ucounter] + '', 
         'Authorization':'Token ' + toket}
        bomvoice = requests.post(('https://id-api.spooncast.net/users/' + str(idd[0]) + '/impression/'), headers=headers, json={'new_impression_ids': type}, timeout=2)
        il += 1
        print(il)
        if il == 50:
            ucounter += 1
    except:
        print('err')

print('berhasil terganti ?? hehe ')
