## Hello word👋
##### Update 30 July 2021
````
Coded by : Romi Afrizal
````
## Installation
$ pkg update && pkg upgrade <br>
$ pkg install python2 <br>
$ pkg install git <br>
$ git clone https://github.com/Mark-Zuck/bff-2 <br>
$ cd bff-2 <br>
$ pip2 install -r requirements.txt<br>
$ python2 bff-2.py<br>
#
#### Info Menu :<br>
• 01 Dump Id Public<br>
• 02 Dump Id Followers<br>
• 03 Dump Id Reaction Post<br>
• 04 Dump Id Member Groups<br>
• 05 Dump Id Pencarian Nama<br>
• 06 Dump Id Pesan Mesengger<br>
• 07 Mulai Crack<br>
• 08 Ganti User Agent<br>
• 09 Cek Hasil Crack<br>
• rm Hapus Akun<br>
• 00 Keluar<br>
#### Methode crack :
• 1 Methode api (fast crack) <br>
• 2 Methode free (slow crack)<br>
• 3 Methode mobile (very slow crack) <br>
#
#### Want to recode? Permit first. Appreciate the maker bro!
#
<img src="https://github.com/Mark-Zuck/bff-2/blob/main/rom/20210426_092630.jpg" width="640" title="Menu" alt="Menu">

#
If you can't use this script or there is a bug in the script, please contact me
#### contact me
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/100002461344178)
[![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6282371648186?text=Asalamualaikum+bang)
#### Join groups facebook
[![](https://img.shields.io/badge/Groups-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/310605552656196)
#

<details open> 
<summary> PASSWORD LIST </summary>

#### Indonesia
````
sayang,anjing,kontol,memek,bangsat,
rahasia,indonesia,bismillah,pantek,
123456,12345678,goblok,ganteng,cantik,
cintaku,sayangku
````
#### Malaysia & Singapure
````
malaysia,sayang,anjing,123456,12345678
iloveyou,cintaku,sayangku,bismillah
singapura,rahasia,password
````
#### Bangladesh
````
bangladesh,102030,111222,112233,
123456,12345678,100200,445566
````
#### India & pakistan
````
pakistan,hindia,786786,111222,000786
112233,pakistan786,123456,12345678,
786000,786786786,445566
````
#### Usa
````
qwerty,qwery,123456,iloveyou,12345678
````
#




