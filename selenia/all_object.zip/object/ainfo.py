# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:15:55 2020
# Selector ainfo in line 347 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

url_login = 'https://www.999doge.com/api/web.aspx'
dlogin = 'a=Login&Key=258aed99b1924356909fd825d695a9ac&Username=' + getid['username'] + '&Password=' + getid['password'] + '&Totp='
login = scr.post(url_login, data=dlogin, headers=headers).json()
seswallet = login['SessionCookie']
getwalletdoge = 'a=GetDepositAddress&s=' + seswallet + '&Currency=doge'
pwalletdoge = scr.post(url_login, data=getwalletdoge, headers=headers)
login = scr.post(url_login, data=dlogin, headers=headers).json()
dogbal = login['Doge']['Balance'] / 100000000
depodog = login['Doge']['DepositAddress']
depoltc = login['LTC']['DepositAddress']
depoeth = login['ETH']['DepositAddress']
depobtc = login['DepositAddress']
accid = login['AccountId']
print('Account Information:')
print('ID :', accid)
print('Username : ' + getid['username'])
print('Password : ' + getid['password'])
print('Username & Password For Login 999Doge.com')
print('Balance :')
print('-Doge :', num_format(dogbal))
print('Deposit Address :')
print('-Doge :', depodog)
input('Enter')