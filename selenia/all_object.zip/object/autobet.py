# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Sun Sep 20 17:46:07 2020
# Selector autobet in line 171 file <EzzKun>
# Timestamp in code : 2020-07-16 04:45:22

win = 0
lose = 0
wins = 0
loses = 0
delay = 0
MaxPayIns = 0
MaxBase = 0
MaxPayOuts = 0
TotalProfit = 0
ProfitSementara = 0
PayIn = 0
LProfit = 0
if BaseTrade >= float(1e-08) and BaseTrade < float(0.0001):
    delay = 2
elif BaseTrade >= float(0.0001) and BaseTrade < float(0.001):
    delay = 1
elif BaseTrade >= float(0.001) and BaseTrade < float(0.01):
    delay = 0.5
elif BaseTrade >= float(0.01):
    delay = 0
if x > 150:
    print(hijau + 'Please Buy License')
    print(kuning + 'Max Balance For Free Is 150 Doge', putih)
    sys.exit()
else:
    print(hijau + 'Start Trading' + putih)
    time.sleep(2)
    os.system('clear')
if BaseTrade > 0:
    PayIn = BaseTrade * int(100000000)
else:
    PayIn = BaseTrade / int(100000000)
Profit = 0
NumberOfTrade = random.randint(TC1, TC2)
while True:
    try:
        if TotalProfit < TargetProfit:
            time.sleep(AddDelayTrade)
            ch = round(random.uniform(C2, C1), 2)
            Low = int(1000000) - ch * int(10000)
            PlaceAutoBets = {'a':'PlaceAutomatedBets', 
             's':ses, 
             'BasePayIn':num_PayIn(int(PayIn)), 
             'Low':int(Low), 
             'High':'999999', 
             'MaxBets':int(NumberOfTrade), 
             'ResetOnWin':ResetOnWin, 
             'ResetOnLose':ResetOnLose, 
             'IncreaseOnWinPercent':str(IncreaseOnWinPercent), 
             'IncreaseOnLosePercent':str(IncreaseOnLosePercent), 
             'MaxPayIn':int(MaxBaseTrade), 
             'ResetOnLoseMaxBet':int(ResetOnLoseMaxTrade), 
             'StopOnLoseMaxBet':int(StopOnLoseMaxTrade), 
             'ClientSeed':int(ClientSeed), 
             'Currency':Currency, 
             'ProtocolVersion':'2'}
            post(PlaceAutoBets)
            try:
                if int(req['InsufficientFunds']) == 1:
                    print('\n\nInsufficient Funds')
                    input('Enter')
                else:
                    pass
            except:
                print('hello') # my modificated, to skip parserror
            else: # -> this is nothing
                BetCount = len(req['PayIns']) # -> exception return to this
                PayIns = sum(req['PayIns'])
                PayOuts = sum(req['PayOuts'])
                if MaxPayIns > PayIns:
                    MaxPayIns = PayIns
                count_profit = PayOuts + PayIns
                if MaxPayOuts > count_profit:
                    MaxPayOuts = count_profit
                Profit += count_profit
                TotalProfit = Profit / 100000000
                if PayOuts > 0 and count_profit > 0:
                    win += 1
                    lose = 0
                    if wins < win:
                        wins += 1
                    print(bghijau_white + 'TC:', BetCount, 'TradeIn:', num_format(PayIns / -100000000) + ' TradeProfit:', ' ' + num_format(count_profit / 100000000) + putih)
                    print(hijau, 'Profit :', (num_format(Profit / 100000000) + putih), (hijau + '[W]' + str(win) + ':' + str(wins) + merah), ('[L]' + str(lose) + ':' + str(loses) + putih), end='\r')
                    if BaseTrade > 0:
                        PayIn = BaseTrade * int(100000000)
                        NumberOfTrade = random.randint(TC1, TC2)
                    else:
                        PayIn = BaseTrade / int(100000000)
                        NumberOfTrade = random.randint(TC1, TC2)
                    if SmartRecovery == 'ON':
                        LProfit += count_profit
                        if LProfit > 0:
                            LProfit = 0
                            if BaseTrade > 0:
                                PayIn = BaseTrade * int(100000000)
                                NumberOfTrade = random.randint(TC1, TC2)
                            else:
                                LProfit += Profit
                                PayIn = BaseTrade / int(100000000)
                                NumberOfTrade = random.randint(TC1, TC2)
                        else:
                            LProfit += count_profit
                            if ContinueLastBase == 'ON':
                                PayIn = (req['PayIns'][(-1)] + RecoveryIncrease) * RecoveryMultiplier
                            else:
                                PayIn = (req['PayIns'][0] + RecoveryIncrease) * RecoveryMultiplier
                            if MaxBase == 'ON':
                                MaxBaseTrade = (MaxBaseTrade + RecoveryIncrease) * RecoveryMultiplier
                            elif MaxBase == 'OFF':
                                MaxBaseTrade = 0
                            if ForceTC1AfterLose == 'ON':
                                NumberOfTrade = 1
                            elif ForceTC1AfterLose == 'OFF':
                                NumberOfTrade = random.randint(TC1, TC2)
                            if ChangeTCAfterLose == 'ON':
                                NumberOfTrade = tools['ChangeTCAfterLose']['ChangeTo']
                    else:
                        pass
                    if MaxBase == 'ON':
                        MaxBaseTrade = float(tradeset['MaxBaseTrade']['Max']) * 100000000
                    elif MaxBase == 'OFF':
                        MaxBaseTrade = 0
                    time.sleep(AddDelayTradeWin)
                else:
                    win = 0
                    lose += 1
                    LProfit += count_profit
                    if loses < lose:
                        loses += 1
                    print(bgmerah_black + 'TC:', BetCount, 'TradeIn:', num_format(PayIns / -100000000) + ' TradeProfit:', num_format(count_profit / 100000000) + putih)
                    print(hijau, 'Profit :', (num_format(Profit / 100000000) + putih), (hijau + '[W]' + str(win) + ':' + str(wins) + merah), ('[L]' + str(lose) + ':' + str(loses) + putih), end='\r')
                    if ContinueLastBase == 'ON':
                        PayIn = (req['PayIns'][(-1)] + RecoveryIncrease) * RecoveryMultiplier
                    else:
                        PayIn = (req['PayIns'][0] + RecoveryIncrease) * RecoveryMultiplier
                    if MaxBase == 'ON':
                        MaxBaseTrade = (MaxBaseTrade + RecoveryIncrease) * RecoveryMultiplier
                    elif MaxBase == 'OFF':
                        MaxBaseTrade = 0
                    if ForceTC1AfterLose == 'ON':
                        NumberOfTrade = 1
                    elif ForceTC1AfterLose == 'OFF':
                        NumberOfTrade = random.randint(TC1, TC2)
                    if ChangeTCAfterLose == 'ON':
                        NumberOfTrade = tools['ChangeTCAfterLose']['ChangeTo']
                    else:
                        pass
                    time.sleep(AddDelayTradeLose)
                    time.sleep(delay)
                if Profit < float(StopLoseBalance):
                    print(merah + '\nStop Lose Tercapai' + putih)
                    sys.exit()

            print('\nTrading Complete\nTrade Summary:')
            print(kuning + 'Profit :', num_format(Profit / 100000000))
            print('Higher TradeIn :', num_format(MaxPayIns / -100000000))
            print('Higher PayOut :', num_format(MaxPayOuts / 100000000))
    except Exception as e:
    	try:
    		print(e)
    		input('Enter')
    	finally:
    		e = None

#Instruction context error:
#-> 
# L. 247       482  POP_EXCEPT       
#                 484  BREAK_LOOP          488  'to 488'
#                 486  END_FINALLY      
#               488_0  COME_FROM           484  '484'
#               488_1  COME_FROM           474  '474'

