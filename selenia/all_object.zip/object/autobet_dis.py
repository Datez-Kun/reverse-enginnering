# FileNames : <EzzKun>
# Python Bytecode : 3.8.5
# Selector autobet In Line 171 file autobet.pyc
# Timestamp In Code :  (2020-09-18 19:27:50)

# Method Name:       autobet
# Filename:          <EzzKun>
# Argument count:    1
# Kw-only arguments: 0
# Number of locals:  19
# Stack size:        17
# Flags:             0x00000043 (NOFREE | NEWLOCALS | OPTIMIZED)
# First Line:        171
# Constants:
#    0: None
#    1: 0
#    2: 1e-08
#    3: 0.0001
#    4: 2
#    5: 0.001
#    6: 1
#    7: 0.01
#    8: 0.5
#    9: 150
#   10: 'Please Buy License'
#   11: 'Max Balance For Free Is 150 Doge'
#   12: 'Start Trading'
#   13: 'clear'
#   14: 100000000
#   15: 1000000
#   16: 10000
#   17: 'PlaceAutomatedBets'
#   18: '999999'
#   19: '2'
#   20: ('a', 's', 'BasePayIn', 'Low', 'High', 'MaxBets', 'ResetOnWin', 'ResetOnLose', 'IncreaseOnWinPercent', 'IncreaseOnLosePercent', 'MaxPayIn', 'ResetOnLoseMaxBet', 'StopOnLoseMaxBet', 'ClientSeed', 'Currency', 'ProtocolVersion')
#   21: 'InsufficientFunds'
#   22: '\n\nInsufficient Funds'
#   23: 'Enter'
#   24: 'PayIns'
#   25: 'PayOuts'
#   26: 'TC:'
#   27: 'TradeIn:'
#   28: -100000000
#   29: ' TradeProfit:'
#   30: ' '
#   31: 'Profit :'
#   32: '[W]'
#   33: ':'
#   34: '[L]'
#   35: '\r'
#   36: ('end',)
#   37: 'ON'
#   38: -1
#   39: 'OFF'
#   40: 'ChangeTCAfterLose'
#   41: 'ChangeTo'
#   42: 'MaxBaseTrade'
#   43: 'Max'
#   44: '\nStop Lose Tercapai'
#   45: '\nTrading Complete\nTrade Summary:'
#   46: 'Higher TradeIn :'
#   47: 'Higher PayOut :'
# Names:
#    0: win
#    1: lose
#    2: delay
#    3: BaseTrade
#    4: float
#    5: print
#    6: hijau
#    7: kuning
#    8: putih
#    9: sys
#   10: exit
#   11: time
#   12: sleep
#   13: os
#   14: system
#   15: int
#   16: random
#   17: randint
#   18: TC1
#   19: TC2
#   20: NumberOfTrade
#   21: TargetProfit
#   22: AddDelayTrade
#   23: round
#   24: uniform
#   25: C2
#   26: C1
#   27: ses
#   28: num_PayIn
#   29: ResetOnWin
#   30: ResetOnLose
#   31: str
#   32: IncreaseOnWinPercent
#   33: IncreaseOnLosePercent
#   34: MaxBaseTrade
#   35: ResetOnLoseMaxTrade
#   36: StopOnLoseMaxTrade
#   37: ClientSeed
#   38: Currency
#   39: post
#   40: req
#   41: input
#   42: len
#   43: sum
#   44: bghijau_white
#   45: num_format
#   46: merah
#   47: SmartRecovery
#   48: ContinueLastBase
#   49: RecoveryIncrease
#   50: RecoveryMultiplier
#   51: ForceTC1AfterLose
#   52: ChangeTCAfterLose
#   53: tools
#   54: tradeset
#   55: AddDelayTradeWin
#   56: bgmerah_black
#   57: AddDelayTradeLose
#   58: StopLoseBalance
#   59: Exception
# Varnames:
#	x, wins, loses, MaxPayIns, MaxBase, MaxPayOuts, TotalProfit, ProfitSementara, PayIn, LProfit, Profit, ch, Low, PlaceAutoBets, BetCount, PayIns, PayOuts, count_profit, e
# Positional arguments:
#	x
# Local variables:
#    1: wins
#    2: loses
#    3: MaxPayIns
#    4: MaxBase
#    5: MaxPayOuts
#    6: TotalProfit
#    7: ProfitSementara
#    8: PayIn
#    9: LProfit
#   10: Profit
#   11: ch
#   12: Low
#   13: PlaceAutoBets
#   14: BetCount
#   15: PayIns
#   16: PayOuts
#   17: count_profit
#   18: e
181           0 LOAD_CONST               1 (0)
              2 STORE_GLOBAL             0 (win)

182           4 LOAD_CONST               1 (0)
              6 STORE_GLOBAL             1 (lose)

183           8 LOAD_CONST               1 (0)
             10 STORE_FAST               1 (wins)

184          12 LOAD_CONST               1 (0)
             14 STORE_FAST               2 (loses)

185          16 LOAD_CONST               1 (0)
             18 STORE_GLOBAL             2 (delay)

186          20 LOAD_CONST               1 (0)
             22 STORE_FAST               3 (MaxPayIns)

187          24 LOAD_CONST               1 (0)
             26 STORE_FAST               4 (MaxBase)

188          28 LOAD_CONST               1 (0)
             30 STORE_FAST               5 (MaxPayOuts)

189          32 LOAD_CONST               1 (0)
             34 STORE_FAST               6 (TotalProfit)

190          36 LOAD_CONST               1 (0)
             38 STORE_FAST               7 (ProfitSementara)

191          40 LOAD_CONST               1 (0)
             42 STORE_FAST               8 (PayIn)

192          44 LOAD_CONST               1 (0)
             46 STORE_FAST               9 (LProfit)

193          48 LOAD_GLOBAL              3 (BaseTrade)
             50 LOAD_GLOBAL              4 (float)
             52 LOAD_CONST               2 (1e-08)
             54 CALL_FUNCTION            1
             56 COMPARE_OP               5 (>=)
             58 POP_JUMP_IF_FALSE       78
             60 LOAD_GLOBAL              3 (BaseTrade)
             62 LOAD_GLOBAL              4 (float)
             64 LOAD_CONST               3 (0.0001)
             66 CALL_FUNCTION            1
             68 COMPARE_OP               0 (<)
             70 POP_JUMP_IF_FALSE       78

194          72 LOAD_CONST               4 (2)
             74 STORE_GLOBAL             2 (delay)
             76 JUMP_FORWARD            76 (to 154)

195     >>   78 LOAD_GLOBAL              3 (BaseTrade)
             80 LOAD_GLOBAL              4 (float)
             82 LOAD_CONST               3 (0.0001)
             84 CALL_FUNCTION            1
             86 COMPARE_OP               5 (>=)
             88 POP_JUMP_IF_FALSE      108
             90 LOAD_GLOBAL              3 (BaseTrade)
             92 LOAD_GLOBAL              4 (float)
             94 LOAD_CONST               5 (0.001)
             96 CALL_FUNCTION            1
             98 COMPARE_OP               0 (<)
            100 POP_JUMP_IF_FALSE      108

196         102 LOAD_CONST               6 (1)
            104 STORE_GLOBAL             2 (delay)
            106 JUMP_FORWARD            46 (to 154)

197     >>  108 LOAD_GLOBAL              3 (BaseTrade)
            110 LOAD_GLOBAL              4 (float)
            112 LOAD_CONST               5 (0.001)
            114 CALL_FUNCTION            1
            116 COMPARE_OP               5 (>=)
            118 POP_JUMP_IF_FALSE      138
            120 LOAD_GLOBAL              3 (BaseTrade)
            122 LOAD_GLOBAL              4 (float)
            124 LOAD_CONST               7 (0.01)
            126 CALL_FUNCTION            1
            128 COMPARE_OP               0 (<)
            130 POP_JUMP_IF_FALSE      138

198         132 LOAD_CONST               8 (0.5)
            134 STORE_GLOBAL             2 (delay)
            136 JUMP_FORWARD            16 (to 154)

199     >>  138 LOAD_GLOBAL              3 (BaseTrade)
            140 LOAD_GLOBAL              4 (float)
            142 LOAD_CONST               7 (0.01)
            144 CALL_FUNCTION            1
            146 COMPARE_OP               5 (>=)
            148 POP_JUMP_IF_FALSE      154

200         150 LOAD_CONST               1 (0)
            152 STORE_GLOBAL             2 (delay)

201     >>  154 LOAD_FAST                0 (x)
            156 LOAD_CONST               9 (150)
            158 COMPARE_OP               4 (>)
            160 POP_JUMP_IF_FALSE      198

202         162 LOAD_GLOBAL              5 (print)
            164 LOAD_GLOBAL              6 (hijau)
            166 LOAD_CONST              10 ('Please Buy License')
            168 BINARY_ADD
            170 CALL_FUNCTION            1
            172 POP_TOP

203         174 LOAD_GLOBAL              5 (print)
            176 LOAD_GLOBAL              7 (kuning)
            178 LOAD_CONST              11 ('Max Balance For Free Is 150 Doge')
            180 BINARY_ADD
            182 LOAD_GLOBAL              8 (putih)
            184 CALL_FUNCTION            2
            186 POP_TOP

204         188 LOAD_GLOBAL              9 (sys)
            190 LOAD_METHOD             10 (exit)
            192 CALL_METHOD              0
            194 POP_TOP
            196 JUMP_FORWARD            36 (to 234)

206     >>  198 LOAD_GLOBAL              5 (print)
            200 LOAD_GLOBAL              6 (hijau)
            202 LOAD_CONST              12 ('Start Trading')
            204 BINARY_ADD
            206 LOAD_GLOBAL              8 (putih)
            208 BINARY_ADD
            210 CALL_FUNCTION            1
            212 POP_TOP

207         214 LOAD_GLOBAL             11 (time)
            216 LOAD_METHOD             12 (sleep)
            218 LOAD_CONST               4 (2)
            220 CALL_METHOD              1
            222 POP_TOP

208         224 LOAD_GLOBAL             13 (os)
            226 LOAD_METHOD             14 (system)
            228 LOAD_CONST              13 ('clear')
            230 CALL_METHOD              1
            232 POP_TOP

209     >>  234 LOAD_GLOBAL              3 (BaseTrade)
            236 LOAD_CONST               1 (0)
            238 COMPARE_OP               4 (>)
            240 EXTENDED_ARG             1
            242 POP_JUMP_IF_FALSE      258

210         244 LOAD_GLOBAL              3 (BaseTrade)
            246 LOAD_GLOBAL             15 (int)
            248 LOAD_CONST              14 (100000000)
            250 CALL_FUNCTION            1
            252 BINARY_MULTIPLY
            254 STORE_FAST               8 (PayIn)
            256 JUMP_FORWARD            12 (to 270)

212     >>  258 LOAD_GLOBAL              3 (BaseTrade)
            260 LOAD_GLOBAL             15 (int)
            262 LOAD_CONST              14 (100000000)
            264 CALL_FUNCTION            1
            266 BINARY_TRUE_DIVIDE
            268 STORE_FAST               8 (PayIn)

213     >>  270 LOAD_CONST               1 (0)
            272 STORE_FAST              10 (Profit)

214         274 LOAD_GLOBAL             16 (random)
            276 LOAD_METHOD             17 (randint)
            278 LOAD_GLOBAL             18 (TC1)
            280 LOAD_GLOBAL             19 (TC2)
            282 CALL_METHOD              2
            284 STORE_GLOBAL            20 (NumberOfTrade)
win = 0
lose = 0
wins = 0
loses = 0
delay = 0
MaxPayIns = 0
MaxBase = 0
MaxPayOuts = 0
TotalProfit = 0
ProfitSementara = 0
PayIn = 0
LProfit = 0
if BaseTrade >= float(1e-08) and BaseTrade < float(0.0001):
    delay = 2
else:
    if BaseTrade >= float(0.0001) and BaseTrade < float(0.001):
        delay = 1
    else:
        if BaseTrade >= float(0.001) and BaseTrade < float(0.01):
            delay = 0.5
        else:
            if BaseTrade >= float(0.01):
                delay = 0
            else:
                if x > 150:
                    print(hijau + 'Please Buy License')
                    print(kuning + 'Max Balance For Free Is 150 Doge', putih)
                    sys.exit()
                else:
                    print(hijau + 'Start Trading' + putih)
                    time.sleep(2)
                    os.system('clear')
                if BaseTrade > 0:
                    PayIn = BaseTrade * int(100000000)
                else:
                    PayIn = BaseTrade / int(100000000)
            Profit = 0
            NumberOfTrade = random.randint(TC1, TC2)

215         286 EXTENDED_ARG             5
            288 SETUP_FINALLY         1308 (to 1598)

216     >>  290 LOAD_FAST                6 (TotalProfit)
            292 LOAD_GLOBAL             21 (TargetProfit)
            294 COMPARE_OP               0 (<)
            296 EXTENDED_ARG             5
            298 POP_JUMP_IF_FALSE     1520

218         300 LOAD_GLOBAL             11 (time)
            302 LOAD_METHOD             12 (sleep)
            304 LOAD_GLOBAL             22 (AddDelayTrade)
            306 CALL_METHOD              1
            308 POP_TOP

219         310 LOAD_GLOBAL             23 (round)
            312 LOAD_GLOBAL             16 (random)
            314 LOAD_METHOD             24 (uniform)
            316 LOAD_GLOBAL             25 (C2)
            318 LOAD_GLOBAL             26 (C1)
            320 CALL_METHOD              2
            322 LOAD_CONST               4 (2)
            324 CALL_FUNCTION            2
            326 STORE_FAST              11 (ch)

220         328 LOAD_GLOBAL             15 (int)
            330 LOAD_CONST              15 (1000000)
            332 CALL_FUNCTION            1
            334 LOAD_FAST               11 (ch)
            336 LOAD_GLOBAL             15 (int)
            338 LOAD_CONST              16 (10000)
            340 CALL_FUNCTION            1
            342 BINARY_MULTIPLY
            344 BINARY_SUBTRACT
            346 STORE_FAST              12 (Low)

222         348 LOAD_CONST              17 ('PlaceAutomatedBets')

223         350 LOAD_GLOBAL             27 (ses)

224         352 LOAD_GLOBAL             28 (num_PayIn)
            354 LOAD_GLOBAL             15 (int)
            356 LOAD_FAST                8 (PayIn)
            358 CALL_FUNCTION            1
            360 CALL_FUNCTION            1

225         362 LOAD_GLOBAL             15 (int)
            364 LOAD_FAST               12 (Low)
            366 CALL_FUNCTION            1

226         368 LOAD_CONST              18 ('999999')

227         370 LOAD_GLOBAL             15 (int)
            372 LOAD_GLOBAL             20 (NumberOfTrade)
            374 CALL_FUNCTION            1

228         376 LOAD_GLOBAL             29 (ResetOnWin)

229         378 LOAD_GLOBAL             30 (ResetOnLose)

230         380 LOAD_GLOBAL             31 (str)
            382 LOAD_GLOBAL             32 (IncreaseOnWinPercent)
            384 CALL_FUNCTION            1

231         386 LOAD_GLOBAL             31 (str)
            388 LOAD_GLOBAL             33 (IncreaseOnLosePercent)
            390 CALL_FUNCTION            1

232         392 LOAD_GLOBAL             15 (int)
            394 LOAD_GLOBAL             34 (MaxBaseTrade)
            396 CALL_FUNCTION            1

233         398 LOAD_GLOBAL             15 (int)
            400 LOAD_GLOBAL             35 (ResetOnLoseMaxTrade)
            402 CALL_FUNCTION            1

234         404 LOAD_GLOBAL             15 (int)
            406 LOAD_GLOBAL             36 (StopOnLoseMaxTrade)
            408 CALL_FUNCTION            1

235         410 LOAD_GLOBAL             15 (int)
            412 LOAD_GLOBAL             37 (ClientSeed)
            414 CALL_FUNCTION            1

236         416 LOAD_GLOBAL             38 (Currency)

237         418 LOAD_CONST              19 ('2')

221         420 LOAD_CONST              20 (('a', 's', 'BasePayIn', 'Low', 'High', 'MaxBets', 'ResetOnWin', 'ResetOnLose', 'IncreaseOnWinPercent', 'IncreaseOnLosePercent', 'MaxPayIn', 'ResetOnLoseMaxBet', 'StopOnLoseMaxBet', 'ClientSeed', 'Currency', 'ProtocolVersion'))
            422 BUILD_CONST_KEY_MAP     16
            424 STORE_FAST              13 (PlaceAutoBets)

239         426 LOAD_GLOBAL             39 (post)
            428 LOAD_FAST               13 (PlaceAutoBets)
            430 CALL_FUNCTION            1
            432 POP_TOP
try:
	if TotalProfit < TargetProfit:
		time.sleep(AddDelayTrade)
		ch = round(random.uniform(C2, C1), 2)
		Low = int(1000000) - ch * int(10000)
		PlaceAutoBets = {'a':'PlaceAutomatedBets', 
		 's':ses, 
		 'BasePayIn':num_PayIn(int(PayIn)), 
		 'Low':int(Low), 
		 'High':'999999', 
		 'MaxBets':int(NumberOfTrade), 
		 'ResetOnWin':ResetOnWin, 
		 'ResetOnLose':ResetOnLose, 
		 'IncreaseOnWinPercent':str(IncreaseOnWinPercent), 
		 'IncreaseOnLosePercent':str(IncreaseOnLosePercent), 
		 'MaxPayIn':int(MaxBaseTrade), 
		 'ResetOnLoseMaxBet':int(ResetOnLoseMaxTrade), 
		 'StopOnLoseMaxBet':int(StopOnLoseMaxTrade), 
		 'ClientSeed':int(ClientSeed), 
		 'Currency':Currency, 
		 'ProtocolVersion':'2'}
		post(PlaceAutoBets)

240         434 SETUP_FINALLY           40 (to 476)

241         436 LOAD_GLOBAL             15 (int)
            438 LOAD_GLOBAL             40 (req)
            440 LOAD_CONST              21 ('InsufficientFunds')
            442 BINARY_SUBSCR
            444 CALL_FUNCTION            1
            446 LOAD_CONST               6 (1)
            448 COMPARE_OP               2 (==)
            450 EXTENDED_ARG             1
            452 POP_JUMP_IF_FALSE      472

242         454 LOAD_GLOBAL              5 (print)
            456 LOAD_CONST              22 ('\n\nInsufficient Funds')
            458 CALL_FUNCTION            1
            460 POP_TOP

243         462 LOAD_GLOBAL             41 (input)
            464 LOAD_CONST              23 ('Enter')
            466 CALL_FUNCTION            1
            468 POP_TOP
            470 JUMP_FORWARD             0 (to 472)

245     >>  472 POP_BLOCK
            474 JUMP_FORWARD            12 (to 488)

246     >>  476 POP_TOP
            478 POP_TOP
            480 POP_TOP

247         482 POP_EXCEPT
            484 JUMP_FORWARD             2 (to 488)
            486 END_FINALLY
try:
    if int(req['InsufficientFunds']) == 1:
        print('\n\nInsufficient Funds')
        input('Enter')
    else:
        pass
except:
    pass

248     >>  488 LOAD_GLOBAL             42 (len)
            490 LOAD_GLOBAL             40 (req)
            492 LOAD_CONST              24 ('PayIns')
            494 BINARY_SUBSCR
            496 CALL_FUNCTION            1
            498 STORE_FAST              14 (BetCount)

249         500 LOAD_GLOBAL             43 (sum)
            502 LOAD_GLOBAL             40 (req)
            504 LOAD_CONST              24 ('PayIns')
            506 BINARY_SUBSCR
            508 CALL_FUNCTION            1
            510 STORE_FAST              15 (PayIns)

250         512 LOAD_GLOBAL             43 (sum)
            514 LOAD_GLOBAL             40 (req)
            516 LOAD_CONST              25 ('PayOuts')
            518 BINARY_SUBSCR
            520 CALL_FUNCTION            1
            522 STORE_FAST              16 (PayOuts)

251         524 LOAD_FAST                3 (MaxPayIns)
            526 LOAD_FAST               15 (PayIns)
            528 COMPARE_OP               4 (>)
            530 EXTENDED_ARG             2
            532 POP_JUMP_IF_FALSE      538

252         534 LOAD_FAST               15 (PayIns)
            536 STORE_FAST               3 (MaxPayIns)

253     >>  538 LOAD_FAST               16 (PayOuts)
            540 LOAD_FAST               15 (PayIns)
            542 BINARY_ADD
            544 STORE_FAST              17 (count_profit)

254         546 LOAD_FAST                5 (MaxPayOuts)
            548 LOAD_FAST               17 (count_profit)
            550 COMPARE_OP               4 (>)
            552 EXTENDED_ARG             2
            554 POP_JUMP_IF_FALSE      560

255         556 LOAD_FAST               17 (count_profit)
            558 STORE_FAST               5 (MaxPayOuts)

256     >>  560 LOAD_FAST               10 (Profit)
            562 LOAD_FAST               17 (count_profit)
            564 INPLACE_ADD
            566 STORE_FAST              10 (Profit)

257         568 LOAD_FAST               10 (Profit)
            570 LOAD_CONST              14 (100000000)
            572 BINARY_TRUE_DIVIDE
            574 STORE_FAST               6 (TotalProfit)

258         576 LOAD_FAST               16 (PayOuts)
            578 LOAD_CONST               1 (0)
            580 COMPARE_OP               4 (>)
            582 EXTENDED_ARG             4
            584 POP_JUMP_IF_FALSE     1140
            586 LOAD_FAST               17 (count_profit)
            588 LOAD_CONST               1 (0)
            590 COMPARE_OP               4 (>)
            592 EXTENDED_ARG             4
            594 POP_JUMP_IF_FALSE     1140

259         596 LOAD_GLOBAL              0 (win)
            598 LOAD_CONST               6 (1)
            600 INPLACE_ADD
            602 STORE_GLOBAL             0 (win)

260         604 LOAD_CONST               1 (0)
            606 STORE_GLOBAL             1 (lose)

261         608 LOAD_FAST                1 (wins)
            610 LOAD_GLOBAL              0 (win)
            612 COMPARE_OP               0 (<)
            614 EXTENDED_ARG             2
            616 POP_JUMP_IF_FALSE      626

262         618 LOAD_FAST                1 (wins)
            620 LOAD_CONST               6 (1)
            622 INPLACE_ADD
            624 STORE_FAST               1 (wins)

263     >>  626 LOAD_GLOBAL              5 (print)
            628 LOAD_GLOBAL             44 (bghijau_white)
            630 LOAD_CONST              26 ('TC:')
            632 BINARY_ADD
            634 LOAD_FAST               14 (BetCount)
            636 LOAD_CONST              27 ('TradeIn:')
            638 LOAD_GLOBAL             45 (num_format)
            640 LOAD_FAST               15 (PayIns)
            642 LOAD_CONST              28 (-100000000)
            644 BINARY_TRUE_DIVIDE
            646 CALL_FUNCTION            1
            648 LOAD_CONST              29 (' TradeProfit:')
            650 BINARY_ADD
            652 LOAD_CONST              30 (' ')
            654 LOAD_GLOBAL             45 (num_format)
            656 LOAD_FAST               17 (count_profit)
            658 LOAD_CONST              14 (100000000)
            660 BINARY_TRUE_DIVIDE
            662 CALL_FUNCTION            1
            664 BINARY_ADD
            666 LOAD_GLOBAL              8 (putih)
            668 BINARY_ADD
            670 CALL_FUNCTION            5
            672 POP_TOP

264         674 LOAD_GLOBAL              5 (print)
            676 LOAD_GLOBAL              6 (hijau)
            678 LOAD_CONST              31 ('Profit :')
            680 LOAD_GLOBAL             45 (num_format)
            682 LOAD_FAST               10 (Profit)
            684 LOAD_CONST              14 (100000000)
            686 BINARY_TRUE_DIVIDE
            688 CALL_FUNCTION            1
            690 LOAD_GLOBAL              8 (putih)
            692 BINARY_ADD
            694 LOAD_GLOBAL              6 (hijau)
            696 LOAD_CONST              32 ('[W]')
            698 BINARY_ADD
            700 LOAD_GLOBAL             31 (str)
            702 LOAD_GLOBAL              0 (win)
            704 CALL_FUNCTION            1
            706 BINARY_ADD
            708 LOAD_CONST              33 (':')
            710 BINARY_ADD
            712 LOAD_GLOBAL             31 (str)
            714 LOAD_FAST                1 (wins)
            716 CALL_FUNCTION            1
            718 BINARY_ADD
            720 LOAD_GLOBAL             46 (merah)
            722 BINARY_ADD
            724 LOAD_CONST              34 ('[L]')
            726 LOAD_GLOBAL             31 (str)
            728 LOAD_GLOBAL              1 (lose)
            730 CALL_FUNCTION            1
            732 BINARY_ADD
            734 LOAD_CONST              33 (':')
            736 BINARY_ADD
            738 LOAD_GLOBAL             31 (str)
            740 LOAD_FAST                2 (loses)
            742 CALL_FUNCTION            1
            744 BINARY_ADD
            746 LOAD_GLOBAL              8 (putih)
            748 BINARY_ADD
            750 LOAD_CONST              35 ('\r')
            752 LOAD_CONST              36 (('end',))
            754 CALL_FUNCTION_KW         6
            756 POP_TOP

265         758 LOAD_GLOBAL              3 (BaseTrade)
            760 LOAD_CONST               1 (0)
            762 COMPARE_OP               4 (>)
            764 EXTENDED_ARG             3
            766 POP_JUMP_IF_FALSE      794

266         768 LOAD_GLOBAL              3 (BaseTrade)
            770 LOAD_GLOBAL             15 (int)
            772 LOAD_CONST              14 (100000000)
            774 CALL_FUNCTION            1
            776 BINARY_MULTIPLY
            778 STORE_FAST               8 (PayIn)

267         780 LOAD_GLOBAL             16 (random)
            782 LOAD_METHOD             17 (randint)
            784 LOAD_GLOBAL             18 (TC1)
            786 LOAD_GLOBAL             19 (TC2)
            788 CALL_METHOD              2
            790 STORE_GLOBAL            20 (NumberOfTrade)
            792 JUMP_FORWARD            24 (to 818)

269     >>  794 LOAD_GLOBAL              3 (BaseTrade)
            796 LOAD_GLOBAL             15 (int)
            798 LOAD_CONST              14 (100000000)
            800 CALL_FUNCTION            1
            802 BINARY_TRUE_DIVIDE
            804 STORE_FAST               8 (PayIn)

270         806 LOAD_GLOBAL             16 (random)
            808 LOAD_METHOD             17 (randint)
            810 LOAD_GLOBAL             18 (TC1)
            812 LOAD_GLOBAL             19 (TC2)
            814 CALL_METHOD              2
            816 STORE_GLOBAL            20 (NumberOfTrade)

272     >>  818 LOAD_GLOBAL             47 (SmartRecovery)
            820 LOAD_CONST              37 ('ON')
            822 COMPARE_OP               2 (==)
            824 EXTENDED_ARG             4
            826 POP_JUMP_IF_FALSE     1080

273         828 LOAD_FAST                9 (LProfit)
            830 LOAD_FAST               17 (count_profit)
            832 INPLACE_ADD
            834 STORE_FAST               9 (LProfit)

274         836 LOAD_FAST                9 (LProfit)
            838 LOAD_CONST               1 (0)
            840 COMPARE_OP               4 (>)
            842 EXTENDED_ARG             3
            844 POP_JUMP_IF_FALSE      920

275         846 LOAD_CONST               1 (0)
            848 STORE_FAST               9 (LProfit)

276         850 LOAD_GLOBAL              3 (BaseTrade)
            852 LOAD_CONST               1 (0)
            854 COMPARE_OP               4 (>)
            856 EXTENDED_ARG             3
            858 POP_JUMP_IF_FALSE      886

277         860 LOAD_GLOBAL              3 (BaseTrade)
            862 LOAD_GLOBAL             15 (int)
            864 LOAD_CONST              14 (100000000)
            866 CALL_FUNCTION            1
            868 BINARY_MULTIPLY
            870 STORE_FAST               8 (PayIn)

278         872 LOAD_GLOBAL             16 (random)
            874 LOAD_METHOD             17 (randint)
            876 LOAD_GLOBAL             18 (TC1)
            878 LOAD_GLOBAL             19 (TC2)
            880 CALL_METHOD              2
            882 STORE_GLOBAL            20 (NumberOfTrade)
            884 JUMP_FORWARD            32 (to 918)

280     >>  886 LOAD_FAST                9 (LProfit)
            888 LOAD_FAST               10 (Profit)
            890 INPLACE_ADD
            892 STORE_FAST               9 (LProfit)

281         894 LOAD_GLOBAL              3 (BaseTrade)
            896 LOAD_GLOBAL             15 (int)
            898 LOAD_CONST              14 (100000000)
            900 CALL_FUNCTION            1
            902 BINARY_TRUE_DIVIDE
            904 STORE_FAST               8 (PayIn)

282         906 LOAD_GLOBAL             16 (random)
            908 LOAD_METHOD             17 (randint)
            910 LOAD_GLOBAL             18 (TC1)
            912 LOAD_GLOBAL             19 (TC2)
            914 CALL_METHOD              2
            916 STORE_GLOBAL            20 (NumberOfTrade)
        >>  918 JUMP_FORWARD           160 (to 1080)

284     >>  920 LOAD_FAST                9 (LProfit)
            922 LOAD_FAST               17 (count_profit)
            924 INPLACE_ADD
            926 STORE_FAST               9 (LProfit)

285         928 LOAD_GLOBAL             48 (ContinueLastBase)
            930 LOAD_CONST              37 ('ON')
            932 COMPARE_OP               2 (==)
            934 EXTENDED_ARG             3
            936 POP_JUMP_IF_FALSE      960

286         938 LOAD_GLOBAL             40 (req)
            940 LOAD_CONST              24 ('PayIns')
            942 BINARY_SUBSCR
            944 LOAD_CONST              38 (-1)
            946 BINARY_SUBSCR
            948 LOAD_GLOBAL             49 (RecoveryIncrease)
            950 BINARY_ADD
            952 LOAD_GLOBAL             50 (RecoveryMultiplier)
            954 BINARY_MULTIPLY
            956 STORE_FAST               8 (PayIn)
            958 JUMP_FORWARD            20 (to 980)

288     >>  960 LOAD_GLOBAL             40 (req)
            962 LOAD_CONST              24 ('PayIns')
            964 BINARY_SUBSCR
            966 LOAD_CONST               1 (0)
            968 BINARY_SUBSCR
            970 LOAD_GLOBAL             49 (RecoveryIncrease)
            972 BINARY_ADD
            974 LOAD_GLOBAL             50 (RecoveryMultiplier)
            976 BINARY_MULTIPLY
            978 STORE_FAST               8 (PayIn)

289     >>  980 LOAD_FAST                4 (MaxBase)
            982 LOAD_CONST              37 ('ON')
            984 COMPARE_OP               2 (==)
            986 EXTENDED_ARG             3
            988 POP_JUMP_IF_FALSE     1004

290         990 LOAD_GLOBAL             34 (MaxBaseTrade)
            992 LOAD_GLOBAL             49 (RecoveryIncrease)
            994 BINARY_ADD
            996 LOAD_GLOBAL             50 (RecoveryMultiplier)
            998 BINARY_MULTIPLY
           1000 STORE_GLOBAL            34 (MaxBaseTrade)
           1002 JUMP_FORWARD            14 (to 1018)

291     >> 1004 LOAD_FAST                4 (MaxBase)
           1006 LOAD_CONST              39 ('OFF')
           1008 COMPARE_OP               2 (==)
           1010 EXTENDED_ARG             3
           1012 POP_JUMP_IF_FALSE     1018

292        1014 LOAD_CONST               1 (0)
           1016 STORE_GLOBAL            34 (MaxBaseTrade)

293     >> 1018 LOAD_GLOBAL             51 (ForceTC1AfterLose)
           1020 LOAD_CONST              37 ('ON')
           1022 COMPARE_OP               2 (==)
           1024 EXTENDED_ARG             4
           1026 POP_JUMP_IF_FALSE     1034

294        1028 LOAD_CONST               6 (1)
           1030 STORE_GLOBAL            20 (NumberOfTrade)
           1032 JUMP_FORWARD            22 (to 1056)

295     >> 1034 LOAD_GLOBAL             51 (ForceTC1AfterLose)
           1036 LOAD_CONST              39 ('OFF')
           1038 COMPARE_OP               2 (==)
           1040 EXTENDED_ARG             4
           1042 POP_JUMP_IF_FALSE     1056

296        1044 LOAD_GLOBAL             16 (random)
           1046 LOAD_METHOD             17 (randint)
           1048 LOAD_GLOBAL             18 (TC1)
           1050 LOAD_GLOBAL             19 (TC2)
           1052 CALL_METHOD              2
           1054 STORE_GLOBAL            20 (NumberOfTrade)

297     >> 1056 LOAD_GLOBAL             52 (ChangeTCAfterLose)
           1058 LOAD_CONST              37 ('ON')
           1060 COMPARE_OP               2 (==)
           1062 EXTENDED_ARG             4
           1064 POP_JUMP_IF_FALSE     1080

298        1066 LOAD_GLOBAL             53 (tools)
           1068 LOAD_CONST              40 ('ChangeTCAfterLose')
           1070 BINARY_SUBSCR
           1072 LOAD_CONST              41 ('ChangeTo')
           1074 BINARY_SUBSCR
           1076 STORE_GLOBAL            20 (NumberOfTrade)
           1078 JUMP_FORWARD             0 (to 1080)

301     >> 1080 LOAD_FAST                4 (MaxBase)
           1082 LOAD_CONST              37 ('ON')
           1084 COMPARE_OP               2 (==)
           1086 EXTENDED_ARG             4
           1088 POP_JUMP_IF_FALSE     1112

302        1090 LOAD_GLOBAL              4 (float)
           1092 LOAD_GLOBAL             54 (tradeset)
           1094 LOAD_CONST              42 ('MaxBaseTrade')
           1096 BINARY_SUBSCR
           1098 LOAD_CONST              43 ('Max')
           1100 BINARY_SUBSCR
           1102 CALL_FUNCTION            1
           1104 LOAD_CONST              14 (100000000)
           1106 BINARY_MULTIPLY
           1108 STORE_GLOBAL            34 (MaxBaseTrade)
           1110 JUMP_FORWARD            14 (to 1126)

303     >> 1112 LOAD_FAST                4 (MaxBase)
           1114 LOAD_CONST              39 ('OFF')
           1116 COMPARE_OP               2 (==)
           1118 EXTENDED_ARG             4
           1120 POP_JUMP_IF_FALSE     1126

304        1122 LOAD_CONST               1 (0)
           1124 STORE_GLOBAL            34 (MaxBaseTrade)

305     >> 1126 LOAD_GLOBAL             11 (time)
           1128 LOAD_METHOD             12 (sleep)
           1130 LOAD_GLOBAL             55 (AddDelayTradeWin)
           1132 CALL_METHOD              1
           1134 POP_TOP
           1136 EXTENDED_ARG             1
           1138 JUMP_FORWARD           328 (to 1468)

307     >> 1140 LOAD_CONST               1 (0)
           1142 STORE_GLOBAL             0 (win)

308        1144 LOAD_GLOBAL              1 (lose)
           1146 LOAD_CONST               6 (1)
           1148 INPLACE_ADD
           1150 STORE_GLOBAL             1 (lose)

309        1152 LOAD_FAST                9 (LProfit)
           1154 LOAD_FAST               17 (count_profit)
           1156 INPLACE_ADD
           1158 STORE_FAST               9 (LProfit)

310        1160 LOAD_FAST                2 (loses)
           1162 LOAD_GLOBAL              1 (lose)
           1164 COMPARE_OP               0 (<)
           1166 EXTENDED_ARG             4
           1168 POP_JUMP_IF_FALSE     1178

311        1170 LOAD_FAST                2 (loses)
           1172 LOAD_CONST               6 (1)
           1174 INPLACE_ADD
           1176 STORE_FAST               2 (loses)

312     >> 1178 LOAD_GLOBAL              5 (print)
           1180 LOAD_GLOBAL             56 (bgmerah_black)
           1182 LOAD_CONST              26 ('TC:')
           1184 BINARY_ADD
           1186 LOAD_FAST               14 (BetCount)
           1188 LOAD_CONST              27 ('TradeIn:')
           1190 LOAD_GLOBAL             45 (num_format)
           1192 LOAD_FAST               15 (PayIns)
           1194 LOAD_CONST              28 (-100000000)
           1196 BINARY_TRUE_DIVIDE
           1198 CALL_FUNCTION            1
           1200 LOAD_CONST              29 (' TradeProfit:')
           1202 BINARY_ADD
           1204 LOAD_GLOBAL             45 (num_format)
           1206 LOAD_FAST               17 (count_profit)
           1208 LOAD_CONST              14 (100000000)
           1210 BINARY_TRUE_DIVIDE
           1212 CALL_FUNCTION            1
           1214 LOAD_GLOBAL              8 (putih)
           1216 BINARY_ADD
           1218 CALL_FUNCTION            5
           1220 POP_TOP

313        1222 LOAD_GLOBAL              5 (print)
           1224 LOAD_GLOBAL              6 (hijau)
           1226 LOAD_CONST              31 ('Profit :')
           1228 LOAD_GLOBAL             45 (num_format)
           1230 LOAD_FAST               10 (Profit)
           1232 LOAD_CONST              14 (100000000)
           1234 BINARY_TRUE_DIVIDE
           1236 CALL_FUNCTION            1
           1238 LOAD_GLOBAL              8 (putih)
           1240 BINARY_ADD
           1242 LOAD_GLOBAL              6 (hijau)
           1244 LOAD_CONST              32 ('[W]')
           1246 BINARY_ADD
           1248 LOAD_GLOBAL             31 (str)
           1250 LOAD_GLOBAL              0 (win)
           1252 CALL_FUNCTION            1
           1254 BINARY_ADD
           1256 LOAD_CONST              33 (':')
           1258 BINARY_ADD
           1260 LOAD_GLOBAL             31 (str)
           1262 LOAD_FAST                1 (wins)
           1264 CALL_FUNCTION            1
           1266 BINARY_ADD
           1268 LOAD_GLOBAL             46 (merah)
           1270 BINARY_ADD
           1272 LOAD_CONST              34 ('[L]')
           1274 LOAD_GLOBAL             31 (str)
           1276 LOAD_GLOBAL              1 (lose)
           1278 CALL_FUNCTION            1
           1280 BINARY_ADD
           1282 LOAD_CONST              33 (':')
           1284 BINARY_ADD
           1286 LOAD_GLOBAL             31 (str)
           1288 LOAD_FAST                2 (loses)
           1290 CALL_FUNCTION            1
           1292 BINARY_ADD
           1294 LOAD_GLOBAL              8 (putih)
           1296 BINARY_ADD
           1298 LOAD_CONST              35 ('\r')
           1300 LOAD_CONST              36 (('end',))
           1302 CALL_FUNCTION_KW         6
           1304 POP_TOP

314        1306 LOAD_GLOBAL             48 (ContinueLastBase)
           1308 LOAD_CONST              37 ('ON')
           1310 COMPARE_OP               2 (==)
           1312 EXTENDED_ARG             5
           1314 POP_JUMP_IF_FALSE     1338

315        1316 LOAD_GLOBAL             40 (req)
           1318 LOAD_CONST              24 ('PayIns')
           1320 BINARY_SUBSCR
           1322 LOAD_CONST              38 (-1)
           1324 BINARY_SUBSCR
           1326 LOAD_GLOBAL             49 (RecoveryIncrease)
           1328 BINARY_ADD
           1330 LOAD_GLOBAL             50 (RecoveryMultiplier)
           1332 BINARY_MULTIPLY
           1334 STORE_FAST               8 (PayIn)
           1336 JUMP_FORWARD            20 (to 1358)

317     >> 1338 LOAD_GLOBAL             40 (req)
           1340 LOAD_CONST              24 ('PayIns')
           1342 BINARY_SUBSCR
           1344 LOAD_CONST               1 (0)
           1346 BINARY_SUBSCR
           1348 LOAD_GLOBAL             49 (RecoveryIncrease)
           1350 BINARY_ADD
           1352 LOAD_GLOBAL             50 (RecoveryMultiplier)
           1354 BINARY_MULTIPLY
           1356 STORE_FAST               8 (PayIn)

318     >> 1358 LOAD_FAST                4 (MaxBase)
           1360 LOAD_CONST              37 ('ON')
           1362 COMPARE_OP               2 (==)
           1364 EXTENDED_ARG             5
           1366 POP_JUMP_IF_FALSE     1382

319        1368 LOAD_GLOBAL             34 (MaxBaseTrade)
           1370 LOAD_GLOBAL             49 (RecoveryIncrease)
           1372 BINARY_ADD
           1374 LOAD_GLOBAL             50 (RecoveryMultiplier)
           1376 BINARY_MULTIPLY
           1378 STORE_GLOBAL            34 (MaxBaseTrade)
           1380 JUMP_FORWARD            14 (to 1396)

320     >> 1382 LOAD_FAST                4 (MaxBase)
           1384 LOAD_CONST              39 ('OFF')
           1386 COMPARE_OP               2 (==)
           1388 EXTENDED_ARG             5
           1390 POP_JUMP_IF_FALSE     1396

321        1392 LOAD_CONST               1 (0)
           1394 STORE_GLOBAL            34 (MaxBaseTrade)

322     >> 1396 LOAD_GLOBAL             51 (ForceTC1AfterLose)
           1398 LOAD_CONST              37 ('ON')
           1400 COMPARE_OP               2 (==)
           1402 EXTENDED_ARG             5
           1404 POP_JUMP_IF_FALSE     1412

323        1406 LOAD_CONST               6 (1)
           1408 STORE_GLOBAL            20 (NumberOfTrade)
           1410 JUMP_FORWARD            22 (to 1434)

324     >> 1412 LOAD_GLOBAL             51 (ForceTC1AfterLose)
           1414 LOAD_CONST              39 ('OFF')
           1416 COMPARE_OP               2 (==)
           1418 EXTENDED_ARG             5
           1420 POP_JUMP_IF_FALSE     1434

325        1422 LOAD_GLOBAL             16 (random)
           1424 LOAD_METHOD             17 (randint)
           1426 LOAD_GLOBAL             18 (TC1)
           1428 LOAD_GLOBAL             19 (TC2)
           1430 CALL_METHOD              2
           1432 STORE_GLOBAL            20 (NumberOfTrade)

326     >> 1434 LOAD_GLOBAL             52 (ChangeTCAfterLose)
           1436 LOAD_CONST              37 ('ON')
           1438 COMPARE_OP               2 (==)
           1440 EXTENDED_ARG             5
           1442 POP_JUMP_IF_FALSE     1458

327        1444 LOAD_GLOBAL             53 (tools)
           1446 LOAD_CONST              40 ('ChangeTCAfterLose')
           1448 BINARY_SUBSCR
           1450 LOAD_CONST              41 ('ChangeTo')
           1452 BINARY_SUBSCR
           1454 STORE_GLOBAL            20 (NumberOfTrade)
           1456 JUMP_FORWARD             0 (to 1458)

330     >> 1458 LOAD_GLOBAL             11 (time)
           1460 LOAD_METHOD             12 (sleep)
           1462 LOAD_GLOBAL             57 (AddDelayTradeLose)
           1464 CALL_METHOD              1
           1466 POP_TOP

331     >> 1468 LOAD_GLOBAL             11 (time)
           1470 LOAD_METHOD             12 (sleep)
           1472 LOAD_GLOBAL              2 (delay)
           1474 CALL_METHOD              1
           1476 POP_TOP

334        1478 LOAD_FAST               10 (Profit)
           1480 LOAD_GLOBAL              4 (float)
           1482 LOAD_GLOBAL             58 (StopLoseBalance)
           1484 CALL_FUNCTION            1
           1486 COMPARE_OP               0 (<)
           1488 EXTENDED_ARG             1
           1490 POP_JUMP_IF_FALSE      290

335        1492 LOAD_GLOBAL              5 (print)
           1494 LOAD_GLOBAL             46 (merah)
           1496 LOAD_CONST              44 ('\nStop Lose Tercapai')
           1498 BINARY_ADD
           1500 LOAD_GLOBAL              8 (putih)
           1502 BINARY_ADD
           1504 CALL_FUNCTION            1
           1506 POP_TOP

336        1508 LOAD_GLOBAL              9 (sys)
           1510 LOAD_METHOD             10 (exit)
           1512 CALL_METHOD              0
           1514 POP_TOP
           1516 EXTENDED_ARG             1
           1518 JUMP_ABSOLUTE          290

338     >> 1520 LOAD_GLOBAL              5 (print)
           1522 LOAD_CONST              45 ('\nTrading Complete\nTrade Summary:')
           1524 CALL_FUNCTION            1
           1526 POP_TOP

339        1528 LOAD_GLOBAL              5 (print)
           1530 LOAD_GLOBAL              7 (kuning)
           1532 LOAD_CONST              31 ('Profit :')
           1534 BINARY_ADD
           1536 LOAD_GLOBAL             45 (num_format)
           1538 LOAD_FAST               10 (Profit)
           1540 LOAD_CONST              14 (100000000)
           1542 BINARY_TRUE_DIVIDE
           1544 CALL_FUNCTION            1
           1546 CALL_FUNCTION            2
           1548 POP_TOP

340        1550 LOAD_GLOBAL              5 (print)
           1552 LOAD_CONST              46 ('Higher TradeIn :')
           1554 LOAD_GLOBAL             45 (num_format)
           1556 LOAD_FAST                3 (MaxPayIns)
           1558 LOAD_CONST              28 (-100000000)
           1560 BINARY_TRUE_DIVIDE
           1562 CALL_FUNCTION            1
           1564 CALL_FUNCTION            2
           1566 POP_TOP

341        1568 LOAD_GLOBAL              5 (print)
           1570 LOAD_CONST              47 ('Higher PayOut :')
           1572 LOAD_GLOBAL             45 (num_format)
           1574 LOAD_FAST                5 (MaxPayOuts)
           1576 LOAD_CONST              14 (100000000)
           1578 BINARY_TRUE_DIVIDE
           1580 CALL_FUNCTION            1
           1582 CALL_FUNCTION            2
           1584 POP_TOP

342        1586 LOAD_GLOBAL             41 (input)
           1588 LOAD_CONST              23 ('Enter')
           1590 CALL_FUNCTION            1
           1592 POP_TOP
           1594 POP_BLOCK
           1596 JUMP_FORWARD            52 (to 1650)

343     >> 1598 DUP_TOP
           1600 LOAD_GLOBAL             59 (Exception)
           1602 COMPARE_OP              10 (exception match)
           1604 EXTENDED_ARG             6
           1606 POP_JUMP_IF_FALSE     1648
           1608 POP_TOP
           1610 STORE_FAST              18 (e)
           1612 POP_TOP
           1614 SETUP_FINALLY           20 (to 1636)

344        1616 LOAD_GLOBAL              5 (print)
           1618 LOAD_FAST               18 (e)
           1620 CALL_FUNCTION            1
           1622 POP_TOP

345        1624 LOAD_GLOBAL             41 (input)
           1626 LOAD_CONST              23 ('Enter')
           1628 CALL_FUNCTION            1
           1630 POP_TOP
           1632 POP_BLOCK
           1634 BEGIN_FINALLY
        >> 1636 LOAD_CONST               0 (None)
           1638 STORE_FAST              18 (e)
           1640 DELETE_FAST             18 (e)
           1642 END_FINALLY
           1644 POP_EXCEPT
           1646 JUMP_FORWARD             2 (to 1650)
        >> 1648 END_FINALLY
        >> 1650 LOAD_CONST               0 (None)
           1652 RETURN_VALUE
