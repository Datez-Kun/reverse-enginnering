# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:07 2020
# Selector check_license in line 434 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

if 'PLTM' in license:
    print(merah + 'This License Not For Premium Login')
    sys.exit()
url_license = 'https://layscape.xyz/selenia/user'
url_license_add = 'https://layscape.xyz/selenia/adduser'
data = {'license':license, 
 'username':Username}
mydatetime = datetime.now()
date = mydatetime.strftime('%Y-%m-%d')
try:
    user_premium_add = scr.post(url_license_add, data=data).json()
    if user_premium_add['status'] == 'Added':
        print(kuning + user_premium_add['status'] + putih)
    else:
        print(kuning + user_premium_add['status'] + putih)
except:
    pass
else:
    try:
        user_premium = scr.post(url_license, data=data).json()
        userdate = user_premium['date']
        userdate_split = int(''.join([i for i in str(userdate).split('-')]))
        date_split = int(''.join([i for i in str(date).split('-')]))
        Expired = int(userdate_split) - int(date_split)
        if Expired > 30:
            Expired = Expired - 70
            if Expired > 60:
                Expired = Expired - 70
            print(hijau + 'Sukses Verify License')
            User = 'Granted'
            print(User)
        else:
            if Expired < 0:
                print(merah + 'License Out of Date' + putih)
                sys.exit()
    except Exception as e:
        try:
            print(e)
            print(hijau + 'User Not Permited To Use This License')
            print(merah + user_premium['status'] + putih)
            sys.exit()
        finally:
            e = None
            del e

    else:
        return Expired