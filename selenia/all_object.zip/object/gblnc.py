# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:12 2020
# Selector gblnc in line 522 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

getbalance = 'a=GetBalance&s=' + ses + '&Currency=doge'
post(getbalance)
dogebalance = req['Balance'] / 100000000
return dogebalance