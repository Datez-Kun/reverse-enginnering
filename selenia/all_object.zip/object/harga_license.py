# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:12 2020
# Selector harga_license in line 107 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

print('Price List License SELENIA TRADEBOT')
print(hijau + '~Premium~' + putih)
print(biru + '[1] 14 Days - 15K IDR SG SERVER - 1 USER - MULTI DEVICE')
print('[2] 30 Days - 25K - IDR SG SERVER - 1 USER - MULTI DEVICE')
print(hijau + '~Platinum~' + putih)
print(biru + '[1] 14 Days - Ì¶2Ì¶5Ì¶K > 15K - SG SERVER - MULTI USER - MULTI DEVICE')
print('[2] 30 Days - Ì¶3Ì¶5Ì¶K > 20K - SG SERVER - MULTI USER - MULTI DEVICE' + putih)
print(kuning + 'Price Valid Until 24/09/2020')
print('Contact Admin :')
print('Whatsapp/Telegram : +6283153942438')
print('*Chat Only*')
input('Enter' + putih)