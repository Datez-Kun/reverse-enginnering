# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:13 2020
# Selector login in line 125 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

otp = ''
data = {'username':Username, 
 'password':Password}
url_get = 'http://layscape.xyz/selenia/getuser.php'
getid = scr.post(url_get, data=data).json()
if getid['status'] == 'Berhasil':
    pass
else:
    print(merah + getid['status'] + putih)
    sys.exit()
otp = input('2FA Code (If Enabled) : ')
login = 'a=Login&Key=e46b7c63f6b647e0bed15b38238700d5&Username=' + getid['username'] + '&Password=' + getid['password'] + '&Totp=' + otp
try:
    post(login)
    ses = req['SessionCookie']
    refer = req['ReferredById']
    dogebalance = req['Doge']['Balance'] / 100000000
    accid = req['AccountId']
    print(hijau + 'Login Success')
    statslogin = 'Online'
    getwalletdoge = 'a=GetDepositAddress&s=' + ses + '&Currency=doge'
    post(getwalletdoge)
    dogewallet = req['Address']
    time.sleep(2)
except Exception as e:
    try:
        print(e)
        print(merah + 'Check Username or Password')
        sys.exit()
    finally:
        e = None
        del e

else:
    return getid