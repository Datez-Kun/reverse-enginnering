# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:14 2020
# Selector post in line 121 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

req = requests.post(url, data=data, headers=headers).json()
return req