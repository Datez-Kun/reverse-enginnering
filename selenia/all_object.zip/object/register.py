# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:14 2020
# Selector register in line 382 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

print('Creating Account')
CreateAccount = 'a=CreateAccount&Key=e46b7c63f6b647e0bed15b38238700d5'
post(CreateAccount)
AccountCookie = req['AccountCookie']
BeginSession = 'a=BeginSession&Key=e46b7c63f6b647e0bed15b38238700d5&AccountCookie=' + AccountCookie
print('Begining Session')
post(BeginSession)
Session = req['SessionCookie']
inpusername = input('Input Username : ')
inppassword = input('Input Password : ')
gen = 'ABCDEFGHIJKLMN0PQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789#*&%$'
grator = lambda lenght: [random.choice(gen) for i in range(lenght)]
u_id = grator(12)
p_id = grator(12)
username_id = ''.join([str(elem) for elem in u_id])
password_id = ''.join([str(elem) for elem in p_id])
data = {'username':inpusername, 
 'password':inppassword, 
 'usernameid':username_id, 
 'passwordid':password_id}
url_create = 'http://layscape.xyz/selenia/create.php'
create = scr.post(url_create, data=data).json()
if create['status'] == 'Registered':
    print(hijau + create['status'] + ' to Server')
else:
    print(merah + create['status'] + ' to Server')
    sys.exit()
CreateUser = 'a=CreateUser&s=' + Session + '&Username=' + username_id + '&Password=' + password_id
post(CreateUser)
try:
    if req['success'] == 1:
        print(hijau + 'Account Registered')
        print('Please Change Login Information In Config')
        input('Enter' + putih)
except:
    pass

try:
    if req['AccountHasUser'] == 1:
        print('Account Has User')
        input('Enter')
except:
    pass

try:
    if req['UsernameTaken'] == 1:
        print('Username Has Been Taken')
        input('Enter')
except:
    pass