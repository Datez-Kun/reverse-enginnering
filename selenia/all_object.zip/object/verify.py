# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:17 2020
# Selector verify in line 373 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

if refer == 317641596:
    print(hijau + 'Success Verify Account' + putih)
else:
    print(merah + 'Account Not Registered' + putih)
    print(kuning + 'Please Register')
    sys.exit()