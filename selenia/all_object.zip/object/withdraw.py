# Filenames : <EzzKun>
# Python bytecode : 3.8
# Time succses decompiled Fri Sep 18 19:16:18 2020
# Selector withdraw in line 86 file <EzzKun>
# Timestamp in code : 2020-09-18 02:01:53

amt = input('Witdraw Amount (0 = withdraw all) : ')
Address = input('Wallet : ')
Amount = int(amt) * 100000000
otp = input('2FA Code (IF Enabled): ')
withdraw_data = 'a=Withdraw&s=' + ses + '&Amount=' + str(Amount) + '&Address=' + Address + '&Totp=' + otp + '&Currency=doge'
withdraw = scr.post(url, data=withdraw_data, headers=headers).json()
try:
    if withdraw['Pending']:
        print(hijau + 'Success Pending' + putih)
        input('')
except:
    pass

try:
    if withdraw['TooSmall']:
        print(hijau + 'Minimum 2 DOGE' + putih)
        input('')
except:
    pass